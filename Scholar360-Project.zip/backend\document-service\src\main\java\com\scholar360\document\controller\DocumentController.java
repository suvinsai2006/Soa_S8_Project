package com.scholar360.document.controller;

import com.scholar360.document.entity.Document;
import com.scholar360.document.repository.DocumentRepository;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.time.LocalDateTime;
import java.util.*;

@RestController
@RequestMapping("/api/documents")
@CrossOrigin(origins = "*")
public class DocumentController {

    private final DocumentRepository documentRepository;

    public DocumentController(DocumentRepository documentRepository) {
        this.documentRepository = documentRepository;
    }

    @PostMapping("/upload")
    public ResponseEntity<?> uploadDocument(
            @RequestParam("applicationId") Long applicationId,
            @RequestParam("studentId") Long studentId,
            @RequestParam("documentType") String documentType,
            @RequestParam(value = "file", required = false) MultipartFile file,
            @RequestParam(value = "fileName", required = false) String customFileName) throws IOException {

        Document doc = new Document();
        doc.setApplicationId(applicationId);
        doc.setStudentId(studentId);
        doc.setDocumentType(documentType);
        doc.setVerificationStatus("PENDING");
        doc.setUploadDate(LocalDateTime.now());

        if (file != null && !file.isEmpty()) {
            doc.setFileName(file.getOriginalFilename());
            doc.setFileType(file.getContentType());
            doc.setFileSize(file.getSize());
            doc.setFileContentBase64(Base64.getEncoder().encodeToString(file.getBytes()));
        } else {
            // Simulated upload with metadata
            doc.setFileName(customFileName != null ? customFileName : documentType.toLowerCase() + ".pdf");
            doc.setFileType("application/pdf");
            doc.setFileSize(245760L);
        }

        Document saved = documentRepository.save(doc);
        return ResponseEntity.ok(saved);
    }

    @GetMapping("/application/{applicationId}")
    public List<Document> getByApplicationId(@PathVariable Long applicationId) {
        return documentRepository.findByApplicationId(applicationId);
    }

    @GetMapping("/student/{studentId}")
    public List<Document> getByStudentId(@PathVariable Long studentId) {
        return documentRepository.findByStudentId(studentId);
    }

    @GetMapping("/{id}")
    public ResponseEntity<Document> getById(@PathVariable Long id) {
        return documentRepository.findById(id)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    @PutMapping("/{id}/verify")
    public ResponseEntity<?> verifyDocument(@PathVariable Long id, @RequestBody Map<String, String> payload) {
        String status = payload.get("status"); // VERIFIED or REJECTED
        String notes = payload.get("notes");
        String verifiedBy = payload.get("verifiedBy");

        return documentRepository.findById(id).map(doc -> {
            if (status != null) doc.setVerificationStatus(status);
            if (notes != null) doc.setVerificationNotes(notes);
            if (verifiedBy != null) doc.setVerifiedBy(verifiedBy);
            doc.setVerifiedAt(LocalDateTime.now());
            Document saved = documentRepository.save(doc);
            return ResponseEntity.ok(saved);
        }).orElse(ResponseEntity.notFound().build());
    }

    @GetMapping("/pending")
    public List<Document> getPendingVerification() {
        return documentRepository.findByVerificationStatus("PENDING");
    }
}

