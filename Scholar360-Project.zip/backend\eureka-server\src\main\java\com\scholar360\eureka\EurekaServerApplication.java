package com.scholar360.eureka;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.netflix.eureka.server.EnableEurekaServer;

@SpringBootApplication
@EnableEurekaServer
public class EurekaServerApplication {
    public static void main(String[] args) {
        System.out.println("==========================================================");
        System.out.println("   Starting Spring Cloud Eureka Discovery Server (:8761)  ");
        System.out.println("   Dashboard: http://localhost:8761                       ");
        System.out.println("==========================================================");
        SpringApplication.run(EurekaServerApplication.class, args);
    }
}

