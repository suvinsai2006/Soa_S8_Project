import React, { useState, useEffect } from 'react';
import Navbar from './components/Navbar';
import StudentPortal from './components/StudentPortal';
import AdminPortal from './components/AdminPortal';
import ArchitectureView from './components/ArchitectureView';
import AddStudentModal from './components/AddStudentModal';
import { api } from './api';
import { 
  INITIAL_STUDENTS, 
  INITIAL_ADMIN, 
  INITIAL_SCHOLARSHIPS, 
  INITIAL_APPLICATIONS 
} from './mockData';

export default function App() {
  const [view, setView] = useState('student'); // 'student', 'admin', 'architecture'
  const [currentRole, setCurrentRole] = useState('STUDENT');
  const [students, setStudents] = useState(INITIAL_STUDENTS);
  const [adminUser, setAdminUser] = useState(INITIAL_ADMIN);
  const [currentUser, setCurrentUser] = useState(INITIAL_STUDENTS[0]);
  const [isAddStudentOpen, setIsAddStudentOpen] = useState(false);
  
  const [scholarships, setScholarships] = useState(INITIAL_SCHOLARSHIPS);
  const [applications, setApplications] = useState(INITIAL_APPLICATIONS);

  const loadData = async () => {
    const s = await api.getScholarships();
    setScholarships(s);

    const a = await api.getApplications();
    setApplications(a);

    const stds = await api.getStudents();
    setStudents(stds);
    return stds;
  };

  useEffect(() => {
    loadData();
  }, []);

  const handleAddStudent = async (studentData) => {
    const created = await api.addStudent(studentData);
    const updatedList = await api.getStudents();
    setStudents(updatedList);
    // Find the created student in the list or use created
    const found = updatedList.find(s => s.email === studentData.email || s.rollNumber === studentData.rollNumber) || created;
    setCurrentUser(found);
    setCurrentRole('STUDENT');
    setView('student');
  };

  const handleDeleteStudent = async (studentId) => {
    await api.deleteStudent(studentId);
    const updatedList = await api.getStudents();
    setStudents(updatedList);

    // If deleted user was active, switch to first student
    if (currentUser?.id === Number(studentId) || currentUser?.id === studentId) {
      if (updatedList && updatedList.length > 0) {
        setCurrentUser(updatedList[0]);
      } else {
        setCurrentUser(adminUser);
        setCurrentRole('ADMIN');
        setView('admin');
      }
    }
  };

  return (
    <div className="app-container">
      {/* Top Navbar */}
      <Navbar
        currentRole={currentRole}
        setCurrentRole={setCurrentRole}
        currentUser={currentUser}
        setCurrentUser={setCurrentUser}
        students={students}
        admin={adminUser}
        view={view}
        setView={setView}
        onOpenAddStudent={() => setIsAddStudentOpen(true)}
        onDeleteStudent={handleDeleteStudent}
      />

      {/* Main View Area */}
      <main className="main-content">
        {view === 'student' && (
          <StudentPortal
            currentUser={currentUser}
            scholarships={scholarships}
            applications={applications}
            students={students}
            onRefresh={loadData}
            onOpenAddStudent={() => setIsAddStudentOpen(true)}
            onDeleteStudent={handleDeleteStudent}
          />
        )}

        {view === 'admin' && (
          <AdminPortal
            applications={applications}
            scholarships={scholarships}
            adminUser={adminUser}
            students={students}
            onRefresh={loadData}
            onOpenAddStudent={() => setIsAddStudentOpen(true)}
            onDeleteStudent={handleDeleteStudent}
            onSelectStudent={(std) => {
              setCurrentUser(std);
              setCurrentRole('STUDENT');
              setView('student');
            }}
          />
        )}

        {view === 'architecture' && (
          <ArchitectureView />
        )}
      </main>

      {/* Global Add Student Modal */}
      <AddStudentModal
        isOpen={isAddStudentOpen}
        onClose={() => setIsAddStudentOpen(false)}
        onAddStudent={handleAddStudent}
        onDeleteStudent={handleDeleteStudent}
        students={students}
      />

      {/* Footer */}
      <footer style={{
        borderTop: '1px solid #e2e8f0',
        padding: '16px 20px',
        textAlign: 'center',
        fontSize: '12px',
        color: '#64748b',
        background: '#ffffff',
        marginTop: 'auto'
      }}>
        <div style={{ maxWidth: '1200px', margin: '0 auto', display: 'flex', justifyContent: 'space-between', alignItems: 'center', flexWrap: 'wrap', gap: '8px' }}>
          <span><strong>Scholar360</strong> — Digital Scholarship Management Platform</span>
          <span>Course: SOA Programming and Microservices (24SDCS03)</span>
        </div>
      </footer>
    </div>
  );
}
