package com.scholar360.unified;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

@SpringBootApplication
@ComponentScan(basePackages = "com.scholar360")
@EntityScan(basePackages = "com.scholar360")
@EnableJpaRepositories(basePackages = "com.scholar360")
public class UnifiedApplication {
    public static void main(String[] args) {
        System.out.println("==================================================================");
        System.out.println("   Scholar360 - Spring Boot & Spring Cloud Microservices Platform ");
        System.out.println("   Course: SOA Programming and Microservices (24SDCS03)           ");
        System.out.println("   KLH CSE Bowrampet Campus | Batch 18                            ");
        System.out.println("   Backend Running at: http://localhost:8080                      ");
        System.out.println("==================================================================");
        SpringApplication.run(UnifiedApplication.class, args);
    }
}

