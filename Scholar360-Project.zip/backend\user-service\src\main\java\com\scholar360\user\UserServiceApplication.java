package com.scholar360.user;

import com.scholar360.user.entity.User;
import com.scholar360.user.repository.UserRepository;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;
import org.springframework.context.annotation.Bean;

@SpringBootApplication
@EnableDiscoveryClient
public class UserServiceApplication {

    public static void main(String[] args) {
        SpringApplication.run(UserServiceApplication.class, args);
    }

    @Bean
    CommandLineRunner initUsers(UserRepository userRepository) {
        return args -> {
            if (userRepository.count() == 0) {
                userRepository.save(new User(
                        "Student 1", "student1@univ.edu", "student123", "STUDENT",
                        "2420030115", "Computer Science and Engineering", 8.92, 350000.0,
                        "OBC", "+91 9876543210", "2026-2027"
                ));

                userRepository.save(new User(
                        "Student 2", "student2@univ.edu", "student123", "STUDENT",
                        "2420030128", "Computer Science and Engineering", 9.15, 420000.0,
                        "General", "+91 9876543211", "2026-2027"
                ));

                userRepository.save(new User(
                        "Student 3", "student3@univ.edu", "student123", "STUDENT",
                        "2420030124", "Computer Science and Engineering", 8.45, 280000.0,
                        "EWS", "+91 9876543212", "2026-2027"
                ));

                userRepository.save(new User(
                        "Faculty Administrator", "admin@univ.edu", "admin123", "ADMIN",
                        "FAC-CSE-104", "Department of CSE", null, null,
                        null, "+91 9440012345", "Faculty"
                ));
            }
        };
    }
}
