package com.scholar360.gateway;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;

@SpringBootApplication
@EnableDiscoveryClient
public class ApiGatewayApplication {
    public static void main(String[] args) {
        System.out.println("==========================================================");
        System.out.println("   Starting Spring Cloud API Gateway (:8080)              ");
        System.out.println("   Routing to Microservices via Eureka Service Discovery  ");
        System.out.println("==========================================================");
        SpringApplication.run(ApiGatewayApplication.class, args);
    }
}

