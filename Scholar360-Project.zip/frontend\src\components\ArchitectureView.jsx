import React from 'react';
import { WORKFLOW_STAGES } from '../mockData';

export default function ArchitectureView() {
  const services = [
    { name: "User Management Service", port: 8081, desc: "Profiles, roles & authentication" },
    { name: "Scholarship Management Service", port: 8082, desc: "Scholarship catalog & criteria engine" },
    { name: "Application Management Service", port: 8083, desc: "Application workflow & status" },
    { name: "Document Management Service", port: 8084, desc: "Certificate uploads & verification" },
    { name: "Notification Service", port: 8085, desc: "Status alerts & announcements" },
    { name: "Admin & Monitoring Service", port: 8086, desc: "Audit logs & system metrics" }
  ];

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: '20px' }}>
      {/* 3-Tier Layered Architecture Card */}
      <div className="card" style={{ padding: '20px' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: '8px', marginBottom: '4px' }}>
          <h2 style={{ fontSize: '16px', fontWeight: 800, color: '#0f172a' }}>
            System Architecture (SOA &amp; Microservices)
          </h2>
        </div>
        <p style={{ fontSize: '12px', color: '#64748b', marginBottom: '16px' }}>
          Decomposed into independently deployable Spring Boot microservices
        </p>

        <div style={{ display: 'flex', flexDirection: 'column', gap: '10px' }}>
          {/* Frontend */}
          <div style={{ background: '#f0fdfa', border: '1px solid #99f6e4', borderRadius: '8px', padding: '12px', textAlign: 'center' }}>
            <div style={{ fontWeight: 700, color: '#115e59', fontSize: '13px' }}>
              Frontend Layer: React.js (Port 3000)
            </div>
            <div style={{ fontSize: '11px', color: '#0d9488' }}>
              Student Portal • Faculty Administration Desk
            </div>
          </div>

          <div style={{ textAlign: 'center', color: '#94a3b8', fontSize: '11px' }}>↓ RESTful JSON APIs ↓</div>

          {/* Gateway & Eureka */}
          <div style={{ background: '#f8fafc', border: '1px solid #cbd5e1', borderRadius: '8px', padding: '10px', textAlign: 'center' }}>
            <div style={{ fontWeight: 700, color: '#334155', fontSize: '12px' }}>
              Spring Cloud Gateway (:8080) &amp; Eureka Discovery Server (:8761)
            </div>
          </div>

          <div style={{ textAlign: 'center', color: '#94a3b8', fontSize: '11px' }}>↓ Microservice Routing ↓</div>

          {/* Microservices Grid */}
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(220px, 1fr))', gap: '8px' }}>
            {services.map(s => (
              <div key={s.name} style={{ background: '#ffffff', border: '1px solid #e2e8f0', borderRadius: '6px', padding: '10px' }}>
                <div style={{ fontWeight: 700, fontSize: '12px', color: '#0f172a' }}>
                  {s.name}
                </div>
                <div style={{ fontSize: '11px', color: '#64748b' }}>{s.desc}</div>
              </div>
            ))}
          </div>

          <div style={{ textAlign: 'center', color: '#94a3b8', fontSize: '11px' }}>↓ Data Persistence Layer ↓</div>

          {/* Database */}
          <div style={{ background: '#f0fdf4', border: '1px solid #bbf7d0', borderRadius: '8px', padding: '10px', textAlign: 'center' }}>
            <div style={{ fontWeight: 700, color: '#166534', fontSize: '12px' }}>
              Relational Storage Layer (H2 In-Memory / MySQL Database)
            </div>
          </div>
        </div>
      </div>

      {/* 9-Step Lifecycle Workflow */}
      <div className="card" style={{ padding: '20px' }}>
        <h3 style={{ fontSize: '15px', fontWeight: 800, color: '#0f172a', marginBottom: '2px' }}>
          9-Step Application Lifecycle Workflow
        </h3>
        <p style={{ fontSize: '12px', color: '#64748b', marginBottom: '14px' }}>
          End-to-end scholarship verification and disbursement lifecycle
        </p>

        <div style={{
          display: 'grid',
          gridTemplateColumns: 'repeat(auto-fit, minmax(105px, 1fr))',
          gap: '6px'
        }}>
          {WORKFLOW_STAGES.map(s => (
            <div
              key={s.step}
              style={{
                border: '1px solid #e2e8f0',
                borderRadius: '6px',
                padding: '8px 4px',
                textAlign: 'center',
                background: '#f8fafc'
              }}
            >
              <div style={{
                width: '22px',
                height: '22px',
                borderRadius: '50%',
                background: '#0d9488',
                color: '#fff',
                fontSize: '10px',
                fontWeight: 700,
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                margin: '0 auto 4px auto'
              }}>
                {s.step}
              </div>
              <div style={{ fontSize: '11px', fontWeight: 700, color: '#1e293b' }}>
                {s.name}
              </div>
              <div style={{ fontSize: '9px', color: '#64748b' }}>
                {s.desc}
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
