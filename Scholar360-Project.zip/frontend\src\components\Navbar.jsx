import React from 'react';
import { GraduationCap, Users, UserPlus, Trash2 } from 'lucide-react';

export default function Navbar({ 
  currentRole, 
  setCurrentRole, 
  currentUser, 
  setCurrentUser, 
  students, 
  admin,
  view,
  setView,
  onOpenAddStudent,
  onDeleteStudent
}) {
  return (
    <header style={{
      background: '#ffffff',
      borderBottom: '1px solid #e2e8f0',
      position: 'sticky',
      top: 0,
      zIndex: 50
    }}>
      {/* Main Navbar */}
      <div style={{
        maxWidth: '1140px',
        margin: '0 auto',
        padding: '10px 20px',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'space-between',
        flexWrap: 'wrap',
        gap: '12px'
      }}>
        {/* Brand */}
        <div 
          onClick={() => setView('student')} 
          style={{ display: 'flex', alignItems: 'center', gap: '10px', cursor: 'pointer' }}
        >
          <div style={{
            width: '36px',
            height: '36px',
            borderRadius: '10px',
            background: 'linear-gradient(135deg, #0d9488 0%, #0f766e 100%)',
            color: '#fff',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            boxShadow: '0 2px 5px rgba(13, 148, 136, 0.25)'
          }}>
            <GraduationCap size={20} />
          </div>
          <div>
            <div style={{ fontSize: '18px', fontWeight: 800, color: '#0f172a', letterSpacing: '-0.02em' }}>
              Scholar<span style={{ color: '#0d9488' }}>360</span>
            </div>
          </div>
        </div>

        {/* View Switcher: Minimal Pill Toggle */}
        <div style={{
          display: 'flex',
          background: '#f1f5f9',
          padding: '3px',
          borderRadius: '8px',
          gap: '2px'
        }}>
          <button
            onClick={() => { setView('student'); setCurrentRole('STUDENT'); setCurrentUser(students[0] || admin); }}
            style={{
              padding: '6px 14px',
              border: 'none',
              borderRadius: '6px',
              fontWeight: 600,
              fontSize: '12px',
              cursor: 'pointer',
              background: view === 'student' ? '#ffffff' : 'transparent',
              color: view === 'student' ? '#0d9488' : '#64748b',
              boxShadow: view === 'student' ? '0 1px 2px rgba(0,0,0,0.06)' : 'none'
            }}
          >
            Student Portal
          </button>

          <button
            onClick={() => { setView('admin'); setCurrentRole('ADMIN'); setCurrentUser(admin); }}
            style={{
              padding: '6px 14px',
              border: 'none',
              borderRadius: '6px',
              fontWeight: 600,
              fontSize: '12px',
              cursor: 'pointer',
              background: view === 'admin' ? '#ffffff' : 'transparent',
              color: view === 'admin' ? '#0d9488' : '#64748b',
              boxShadow: view === 'admin' ? '0 1px 2px rgba(0,0,0,0.06)' : 'none'
            }}
          >
            Admin Portal
          </button>

          <button
            onClick={() => setView('architecture')}
            style={{
              padding: '6px 14px',
              border: 'none',
              borderRadius: '6px',
              fontWeight: 600,
              fontSize: '12px',
              cursor: 'pointer',
              background: view === 'architecture' ? '#ffffff' : 'transparent',
              color: view === 'architecture' ? '#0d9488' : '#64748b',
              boxShadow: view === 'architecture' ? '0 1px 2px rgba(0,0,0,0.06)' : 'none'
            }}
          >
            SOA Architecture
          </button>
        </div>

        {/* User Switcher Dropdown & Add Student Button */}
        <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
          <span style={{ fontSize: '12px', color: '#64748b' }}>Profile:</span>
          <select
            value={currentUser?.id}
            onChange={(e) => {
              const id = Number(e.target.value);
              if (id === admin.id) {
                setCurrentUser(admin);
                setCurrentRole('ADMIN');
                setView('admin');
              } else {
                const std = students.find(s => s.id === id);
                if (std) {
                  setCurrentUser(std);
                  setCurrentRole('STUDENT');
                  setView('student');
                }
              }
            }}
            className="select"
            style={{ padding: '5px 10px', fontSize: '12px', width: 'auto', background: '#f8fafc' }}
          >
            {students.map(s => (
              <option key={s.id} value={s.id}>
                {s.fullName} (UID: {s.rollNumber})
              </option>
            ))}
            <option value={admin.id}>
              {admin.fullName}
            </option>
          </select>

          <button
            onClick={onOpenAddStudent}
            className="btn btn-primary btn-sm"
            style={{
              padding: '5px 10px',
              fontSize: '11px',
              display: 'flex',
              alignItems: 'center',
              gap: '4px',
              whiteSpace: 'nowrap'
            }}
            title="Register a new student"
          >
            <UserPlus size={13} />
            <span>+ Add Student</span>
          </button>

          {currentUser?.role === 'STUDENT' && (
            <button
              onClick={() => {
                if (window.confirm(`Are you sure you want to remove ${currentUser.fullName} (University ID: ${currentUser.rollNumber})?`)) {
                  onDeleteStudent && onDeleteStudent(currentUser.id);
                }
              }}
              className="btn btn-danger btn-sm"
              style={{
                padding: '5px 8px',
                fontSize: '11px',
                display: 'flex',
                alignItems: 'center',
                gap: '4px',
                whiteSpace: 'nowrap'
              }}
              title={`Remove ${currentUser.fullName}`}
            >
              <Trash2 size={13} />
              <span>Remove</span>
            </button>
          )}
        </div>
      </div>
    </header>
  );
}
