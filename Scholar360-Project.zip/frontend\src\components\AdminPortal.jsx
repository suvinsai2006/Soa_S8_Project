import React, { useState } from 'react';
import { Plus, CheckCircle, XCircle, Award, Users, FileText, X, Trash2, UserPlus, ExternalLink, Search } from 'lucide-react';
import { api } from '../api';

export default function AdminPortal({ 
  applications, 
  scholarships, 
  adminUser, 
  students = [],
  onRefresh,
  onOpenAddStudent,
  onDeleteStudent,
  onSelectStudent
}) {
  const [showAddModal, setShowAddModal] = useState(false);
  const [activeTab, setActiveTab] = useState('applications'); // 'applications' or 'students'
  const [studentSearch, setStudentSearch] = useState('');
  const [newSch, setNewSch] = useState({
    title: '',
    category: 'Merit-Based',
    amount: 50000,
    minCgpa: 8.0,
    maxAnnualIncome: 500000,
    provider: 'University Foundation',
    description: 'Faculty development scholarship program for deserving engineering students.',
    totalSlots: 20
  });

  const totalDisbursed = applications
    .filter(a => a.status === 'APPROVED')
    .reduce((sum, a) => sum + (a.scholarshipAmount || 0), 0);

  const handleUpdateStatus = async (appId, status, remarks) => {
    await api.updateApplicationStatus(appId, status, remarks, adminUser.fullName);
    onRefresh();
  };

  const handleCreateScholarship = async (e) => {
    e.preventDefault();
    await api.addScholarship(newSch);
    setShowAddModal(false);
    onRefresh();
  };

  const handleRemoveStudent = async (student) => {
    if (window.confirm(`Are you sure you want to remove ${student.fullName} (University ID: ${student.rollNumber})?`)) {
      await onDeleteStudent(student.id);
    }
  };

  return (
    <div>
      {/* Admin Greeting */}
      <div className="card" style={{
        padding: '16px 20px',
        marginBottom: '20px',
        display: 'flex',
        justifyContent: 'space-between',
        alignItems: 'center',
        flexWrap: 'wrap',
        gap: '12px',
        borderLeft: '4px solid #115e59'
      }}>
        <div>
          <h2 style={{ fontSize: '18px', fontWeight: 800, color: '#0f172a' }}>
            Faculty &amp; Administration Desk
          </h2>
          <p style={{ fontSize: '12px', color: '#64748b' }}>
            Logged in as <strong>{adminUser.fullName}</strong> ({adminUser.designation})
          </p>
        </div>

        <div style={{ display: 'flex', gap: '8px', flexWrap: 'wrap' }}>
          <button onClick={onOpenAddStudent} className="btn btn-primary btn-sm" style={{ display: 'flex', alignItems: 'center', gap: '5px' }}>
            <UserPlus size={15} /> + Add Student
          </button>
          <button onClick={() => setShowAddModal(true)} className="btn btn-secondary btn-sm" style={{ display: 'flex', alignItems: 'center', gap: '5px' }}>
            <Plus size={15} /> Add Scholarship
          </button>
        </div>
      </div>

      {/* Metrics Row */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(180px, 1fr))', gap: '12px', marginBottom: '20px' }}>
        <div className="card" style={{ padding: '14px 16px' }}>
          <span style={{ fontSize: '11px', color: '#64748b', fontWeight: 600 }}>Total Applications</span>
          <div style={{ fontSize: '22px', fontWeight: 800, color: '#0f172a', marginTop: '2px' }}>
            {applications.length}
          </div>
        </div>

        <div className="card" style={{ padding: '14px 16px' }}>
          <span style={{ fontSize: '11px', color: '#64748b', fontWeight: 600 }}>Registered Students</span>
          <div style={{ fontSize: '22px', fontWeight: 800, color: '#0d9488', marginTop: '2px' }}>
            {students.length}
          </div>
        </div>

        <div className="card" style={{ padding: '14px 16px' }}>
          <span style={{ fontSize: '11px', color: '#64748b', fontWeight: 600 }}>Approved Awards</span>
          <div style={{ fontSize: '22px', fontWeight: 800, color: '#16a34a', marginTop: '2px' }}>
            {applications.filter(a => a.status === 'APPROVED').length}
          </div>
        </div>

        <div className="card" style={{ padding: '14px 16px' }}>
          <span style={{ fontSize: '11px', color: '#64748b', fontWeight: 600 }}>Total Concessions</span>
          <div style={{ fontSize: '22px', fontWeight: 800, color: '#0f766e', marginTop: '2px' }}>
            ₹{totalDisbursed.toLocaleString('en-IN')}
          </div>
        </div>
      </div>

      {/* Admin Tab Switcher */}
      <div style={{ display: 'flex', gap: '8px', marginBottom: '16px' }}>
        <button
          onClick={() => setActiveTab('applications')}
          style={{
            padding: '8px 16px',
            borderRadius: '8px',
            border: 'none',
            fontWeight: 700,
            fontSize: '13px',
            cursor: 'pointer',
            background: activeTab === 'applications' ? '#0d9488' : '#e2e8f0',
            color: activeTab === 'applications' ? '#ffffff' : '#475569'
          }}
        >
          Applications Evaluation ({applications.length})
        </button>

        <button
          onClick={() => setActiveTab('students')}
          style={{
            padding: '8px 16px',
            borderRadius: '8px',
            border: 'none',
            fontWeight: 700,
            fontSize: '13px',
            cursor: 'pointer',
            background: activeTab === 'students' ? '#0d9488' : '#e2e8f0',
            color: activeTab === 'students' ? '#ffffff' : '#475569'
          }}
        >
          Manage Students ({students.length})
        </button>
      </div>

      {/* APPLICATIONS TAB */}
      {activeTab === 'applications' && (
        <div className="card" style={{ padding: '18px' }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '12px' }}>
            <h3 style={{ fontSize: '15px', fontWeight: 800, color: '#0f172a' }}>
              Application Evaluation &amp; Approvals
            </h3>
            <span style={{ fontSize: '12px', color: '#64748b' }}>
              Showing {applications.length} submitted applications
            </span>
          </div>

          <div style={{ overflowX: 'auto' }}>
            <table style={{ width: '100%', borderCollapse: 'collapse', textAlign: 'left', fontSize: '12px' }}>
              <thead>
                <tr style={{ borderBottom: '2px solid #e2e8f0', color: '#64748b', fontSize: '11px', textTransform: 'uppercase' }}>
                  <th style={{ padding: '8px' }}>Ref</th>
                  <th style={{ padding: '8px' }}>Candidate</th>
                  <th style={{ padding: '8px' }}>Scholarship Program</th>
                  <th style={{ padding: '8px' }}>CGPA</th>
                  <th style={{ padding: '8px' }}>Income</th>
                  <th style={{ padding: '8px' }}>Status</th>
                  <th style={{ padding: '8px' }}>Actions</th>
                </tr>
              </thead>
              <tbody>
                {applications.map(app => (
                  <tr key={app.id} style={{ borderBottom: '1px solid #f1f5f9' }}>
                    <td style={{ padding: '10px 8px', fontWeight: 600 }}>#{app.id}</td>
                    <td style={{ padding: '10px 8px' }}>
                      <div style={{ fontWeight: 700 }}>{app.studentName}</div>
                      <div style={{ fontSize: '11px', color: '#64748b' }}>UID: {app.studentRollNumber}</div>
                    </td>
                    <td style={{ padding: '10px 8px' }}>{app.scholarshipTitle}</td>
                    <td style={{ padding: '10px 8px', fontWeight: 700, color: '#0d9488' }}>{app.studentCgpa}</td>
                    <td style={{ padding: '10px 8px' }}>₹{app.annualFamilyIncome?.toLocaleString('en-IN')}</td>
                    <td style={{ padding: '10px 8px' }}>
                      <span className={`badge ${
                        app.status === 'APPROVED' ? 'badge-success' :
                        app.status === 'REJECTED' ? 'badge-danger' :
                        app.status === 'DOCS_VERIFIED' ? 'badge-primary' : 'badge-warning'
                      }`}>
                        {app.status.replace('_', ' ')}
                      </span>
                    </td>
                    <td style={{ padding: '10px 8px' }}>
                      <div style={{ display: 'flex', gap: '6px' }}>
                        <button
                          onClick={() => handleUpdateStatus(app.id, 'APPROVED', `Approved by ${adminUser.fullName}`)}
                          className="btn btn-success btn-sm"
                          style={{ padding: '3px 8px', fontSize: '11px' }}
                        >
                          Approve
                        </button>
                        <button
                          onClick={() => handleUpdateStatus(app.id, 'REJECTED', 'Criteria not satisfied')}
                          className="btn btn-danger btn-sm"
                          style={{ padding: '3px 8px', fontSize: '11px' }}
                        >
                          Reject
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* MANAGE STUDENTS TAB */}
      {activeTab === 'students' && (
        <div className="card" style={{ padding: '18px' }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '14px', flexWrap: 'wrap', gap: '10px' }}>
            <div>
              <h3 style={{ fontSize: '15px', fontWeight: 800, color: '#0f172a' }}>
                Registered Students Directory ({students.length})
              </h3>
              <p style={{ fontSize: '12px', color: '#64748b' }}>
                Add unlimited students or remove students directly from this page.
              </p>
            </div>
            
            <div style={{ display: 'flex', gap: '8px', alignItems: 'center', flexWrap: 'wrap' }}>
              {/* Search Bar */}
              <div style={{ position: 'relative' }}>
                <Search size={14} style={{ position: 'absolute', left: '10px', top: '50%', transform: 'translateY(-50%)', color: '#94a3b8' }} />
                <input
                  type="text"
                  placeholder="Search students..."
                  value={studentSearch}
                  onChange={(e) => setStudentSearch(e.target.value)}
                  className="input"
                  style={{ paddingLeft: '30px', paddingRight: '10px', paddingTop: '5px', paddingBottom: '5px', fontSize: '12px', width: '180px' }}
                />
              </div>

              <button onClick={onOpenAddStudent} className="btn btn-primary btn-sm" style={{ display: 'flex', alignItems: 'center', gap: '6px' }}>
                <UserPlus size={15} /> + Add Student
              </button>
            </div>
          </div>

          <div style={{ overflowX: 'auto', maxHeight: '520px', overflowY: 'auto' }}>
            <table style={{ width: '100%', borderCollapse: 'collapse', textAlign: 'left', fontSize: '12px' }}>
              <thead style={{ position: 'sticky', top: 0, background: '#ffffff', zIndex: 2 }}>
                <tr style={{ borderBottom: '2px solid #e2e8f0', color: '#64748b', fontSize: '11px', textTransform: 'uppercase' }}>
                  <th style={{ padding: '8px' }}>Student</th>
                  <th style={{ padding: '8px' }}>University ID</th>
                  <th style={{ padding: '8px' }}>Department</th>
                  <th style={{ padding: '8px' }}>CGPA</th>
                  <th style={{ padding: '8px' }}>Annual Income</th>
                  <th style={{ padding: '8px' }}>Category</th>
                  <th style={{ padding: '8px', textAlign: 'right' }}>Actions</th>
                </tr>
              </thead>
              <tbody>
                {students
                  .filter(s => {
                    const q = studentSearch.toLowerCase();
                    return (
                      (s.fullName && s.fullName.toLowerCase().includes(q)) ||
                      (s.rollNumber && s.rollNumber.toLowerCase().includes(q)) ||
                      (s.email && s.email.toLowerCase().includes(q)) ||
                      (s.category && s.category.toLowerCase().includes(q))
                    );
                  })
                  .map(s => (
                  <tr key={s.id} style={{ borderBottom: '1px solid #f1f5f9' }}>
                    <td style={{ padding: '10px 8px' }}>
                      <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
                        <div style={{
                          width: '28px',
                          height: '28px',
                          borderRadius: '6px',
                          background: '#f0fdfa',
                          color: '#0d9488',
                          border: '1px solid #99f6e4',
                          fontWeight: 700,
                          fontSize: '11px',
                          display: 'flex',
                          alignItems: 'center',
                          justifyContent: 'center'
                        }}>
                          {s.avatar || s.fullName.substring(0, 2).toUpperCase()}
                        </div>
                        <div>
                          <div style={{ fontWeight: 700, color: '#0f172a' }}>{s.fullName}</div>
                          <div style={{ fontSize: '11px', color: '#64748b' }}>{s.email}</div>
                        </div>
                      </div>
                    </td>
                    <td style={{ padding: '10px 8px', fontWeight: 600 }}>{s.rollNumber}</td>
                    <td style={{ padding: '10px 8px', color: '#475569' }}>{s.department}</td>
                    <td style={{ padding: '10px 8px', fontWeight: 700, color: '#0d9488' }}>{s.cgpa}</td>
                    <td style={{ padding: '10px 8px' }}>₹{s.annualFamilyIncome?.toLocaleString('en-IN')}</td>
                    <td style={{ padding: '10px 8px' }}>
                      <span className="badge badge-primary">{s.category}</span>
                    </td>
                    <td style={{ padding: '10px 8px', textAlign: 'right' }}>
                      <div style={{ display: 'flex', gap: '6px', justifyContent: 'flex-end' }}>
                        <button
                          onClick={() => onSelectStudent && onSelectStudent(s)}
                          className="btn btn-secondary btn-sm"
                          style={{ padding: '3px 8px', fontSize: '11px', display: 'flex', alignItems: 'center', gap: '4px' }}
                          title="Switch to this student profile"
                        >
                          <ExternalLink size={12} /> View
                        </button>
                        <button
                          onClick={() => handleRemoveStudent(s)}
                          className="btn btn-danger btn-sm"
                          style={{ padding: '3px 8px', fontSize: '11px', display: 'flex', alignItems: 'center', gap: '4px' }}
                          title="Remove student from system"
                        >
                          <Trash2 size={12} /> Remove
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* ADD SCHOLARSHIP MODAL */}
      {showAddModal && (
        <div style={{
          position: 'fixed',
          top: 0,
          left: 0,
          right: 0,
          bottom: 0,
          background: 'rgba(0,0,0,0.4)',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          zIndex: 100,
          padding: '20px'
        }}>
          <div className="card" style={{ maxWidth: '440px', width: '100%', padding: '20px', background: '#fff' }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '14px' }}>
              <h3 style={{ fontSize: '16px', fontWeight: 800 }}>Create New Scholarship</h3>
              <button onClick={() => setShowAddModal(false)} style={{ background: 'none', border: 'none', cursor: 'pointer' }}>
                <X size={18} />
              </button>
            </div>

            <form onSubmit={handleCreateScholarship} style={{ display: 'flex', flexDirection: 'column', gap: '10px' }}>
              <div>
                <label style={{ fontSize: '11px', fontWeight: 700, display: 'block', marginBottom: '3px' }}>Program Title</label>
                <input
                  type="text"
                  required
                  className="input"
                  placeholder="e.g. AI Innovation Research Grant"
                  value={newSch.title}
                  onChange={(e) => setNewSch({ ...newSch, title: e.target.value })}
                />
              </div>

              <div style={{ display: 'grid', gridTemplateColumns: 'repeat(2, 1fr)', gap: '10px' }}>
                <div>
                  <label style={{ fontSize: '11px', fontWeight: 700, display: 'block', marginBottom: '3px' }}>Amount (₹)</label>
                  <input
                    type="number"
                    required
                    className="input"
                    value={newSch.amount}
                    onChange={(e) => setNewSch({ ...newSch, amount: parseFloat(e.target.value) })}
                  />
                </div>
                <div>
                  <label style={{ fontSize: '11px', fontWeight: 700, display: 'block', marginBottom: '3px' }}>Min CGPA</label>
                  <input
                    type="number"
                    step="0.1"
                    className="input"
                    value={newSch.minCgpa}
                    onChange={(e) => setNewSch({ ...newSch, minCgpa: parseFloat(e.target.value) })}
                  />
                </div>
              </div>

              <div>
                <label style={{ fontSize: '11px', fontWeight: 700, display: 'block', marginBottom: '3px' }}>Category</label>
                <select
                  className="select"
                  value={newSch.category}
                  onChange={(e) => setNewSch({ ...newSch, category: e.target.value })}
                >
                  <option value="Merit-Based">Merit-Based</option>
                  <option value="Need-Based">Need-Based</option>
                  <option value="Women in STEM">Women in STEM</option>
                </select>
              </div>

              <div style={{ display: 'flex', justifyContent: 'flex-end', gap: '8px', marginTop: '8px' }}>
                <button type="button" onClick={() => setShowAddModal(false)} className="btn btn-secondary btn-sm">
                  Cancel
                </button>
                <button type="submit" className="btn btn-primary btn-sm">
                  Publish
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
