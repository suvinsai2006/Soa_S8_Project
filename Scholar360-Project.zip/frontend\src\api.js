import {
  INITIAL_STUDENTS,
  INITIAL_ADMIN,
  INITIAL_SCHOLARSHIPS,
  INITIAL_APPLICATIONS
} from './mockData';

const BASE_URL = '/api';

const load = (key, fallback) => {
  try {
    const item = localStorage.getItem(`scholar360_${key}`);
    return item ? JSON.parse(item) : fallback;
  } catch (e) {
    return fallback;
  }
};

const save = (key, data) => {
  try {
    localStorage.setItem(`scholar360_${key}`, JSON.stringify(data));
  } catch (e) {}
};

export const api = {
  // Check backend health
  async checkBackend() {
    try {
      const res = await fetch(`${BASE_URL}/admin/system-health`, { signal: AbortSignal.timeout(1500) });
      if (res.ok) return { connected: true, data: await res.json() };
    } catch (e) {}
    return { connected: false, data: null };
  },

  // USERS
  async getStudents() {
    try {
      const res = await fetch(`${BASE_URL}/users/students`, { signal: AbortSignal.timeout(1500) });
      if (res.ok) {
        const data = await res.json();
        save('students', data);
        return data;
      }
    } catch (e) {}
    return load('students', INITIAL_STUDENTS);
  },

  async addStudent(studentData) {
    try {
      const res = await fetch(`${BASE_URL}/users/register`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ 
          ...studentData, 
          role: 'STUDENT', 
          password: studentData.password || 'student123' 
        })
      });
      if (res.ok) {
        const saved = await res.json();
        const list = load('students', INITIAL_STUDENTS);
        list.push(saved);
        save('students', list);
        return saved;
      }
    } catch (e) {}

    const list = load('students', INITIAL_STUDENTS);
    const newStudent = {
      ...studentData,
      id: Date.now(),
      role: 'STUDENT',
      avatar: (studentData.fullName || 'ST').substring(0, 2).toUpperCase()
    };
    list.push(newStudent);
    save('students', list);
    return newStudent;
  },

  async deleteStudent(id) {
    try {
      await fetch(`${BASE_URL}/users/${id}`, { method: 'DELETE' });
    } catch (e) {}

    const list = load('students', INITIAL_STUDENTS);
    const updated = list.filter(s => s.id !== Number(id));
    save('students', updated);
    return updated;
  },

  async getAdmin() {
    return INITIAL_ADMIN;
  },

  // SCHOLARSHIPS
  async getScholarships() {
    try {
      const res = await fetch(`${BASE_URL}/scholarships`, { signal: AbortSignal.timeout(1500) });
      if (res.ok) return await res.json();
    } catch (e) {}
    return load('scholarships', INITIAL_SCHOLARSHIPS);
  },

  async addScholarship(scholarship) {
    try {
      const res = await fetch(`${BASE_URL}/scholarships`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(scholarship)
      });
      if (res.ok) return await res.json();
    } catch (e) {}
    const list = load('scholarships', INITIAL_SCHOLARSHIPS);
    const newSch = { ...scholarship, id: Date.now(), availableSlots: scholarship.totalSlots || 20 };
    list.unshift(newSch);
    save('scholarships', list);
    return newSch;
  },

  // CHECK ELIGIBILITY
  async checkEligibility(scholarshipId, studentProfile) {
    try {
      const res = await fetch(`${BASE_URL}/scholarships/${scholarshipId}/check-eligibility`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(studentProfile)
      });
      if (res.ok) return await res.json();
    } catch (e) {}

    const list = load('scholarships', INITIAL_SCHOLARSHIPS);
    const s = list.find(item => item.id === Number(scholarshipId));
    if (!s) return { eligible: false, checks: [] };

    const checks = [];
    let eligible = true;

    const minCgpa = s.minCgpa || 0;
    const cgpaOk = (studentProfile.cgpa || 0) >= minCgpa;
    checks.push({
      rule: `Minimum CGPA Requirement (>= ${minCgpa})`,
      status: cgpaOk,
      message: cgpaOk ? `CGPA (${studentProfile.cgpa}) qualifies` : `CGPA is below requirement`
    });
    if (!cgpaOk) eligible = false;

    const maxIncome = s.maxAnnualIncome || Infinity;
    const incomeOk = (studentProfile.annualFamilyIncome || 0) <= maxIncome;
    checks.push({
      rule: `Family Annual Income (<= ₹${maxIncome.toLocaleString('en-IN')})`,
      status: incomeOk,
      message: incomeOk ? `Income qualifies` : `Income exceeds upper limit`
    });
    if (!incomeOk) eligible = false;

    return {
      scholarshipId: s.id,
      scholarshipTitle: s.title,
      eligible,
      checks
    };
  },

  // APPLICATIONS
  async getApplications(studentId = null) {
    try {
      const url = studentId ? `${BASE_URL}/applications/student/${studentId}` : `${BASE_URL}/applications`;
      const res = await fetch(url, { signal: AbortSignal.timeout(1500) });
      if (res.ok) return await res.json();
    } catch (e) {}

    const all = load('applications', INITIAL_APPLICATIONS);
    if (studentId) return all.filter(a => a.studentId === Number(studentId));
    return all;
  },

  async apply(applicationData) {
    try {
      const res = await fetch(`${BASE_URL}/applications/apply`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(applicationData)
      });
      if (res.ok) return await res.json();
    } catch (e) {}

    const all = load('applications', INITIAL_APPLICATIONS);
    const newApp = {
      ...applicationData,
      id: Date.now(),
      status: 'SUBMITTED',
      currentWorkflowStep: 4,
      submissionDate: new Date().toISOString(),
      remarks: 'Application submitted successfully. Awaiting document verification.'
    };
    all.unshift(newApp);
    save('applications', all);
    return newApp;
  },

  async updateApplicationStatus(id, status, remarks, reviewedBy = "Faculty Administrator") {
    try {
      const res = await fetch(`${BASE_URL}/applications/${id}/status`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ status, remarks, reviewedBy })
      });
      if (res.ok) return await res.json();
    } catch (e) {}

    const all = load('applications', INITIAL_APPLICATIONS);
    const index = all.findIndex(a => a.id === Number(id));
    if (index !== -1) {
      let step = 4;
      if (status === 'UNDER_REVIEW') step = 5;
      if (status === 'DOCS_VERIFIED') step = 6;
      if (status === 'APPROVED' || status === 'REJECTED') step = 8;

      all[index] = {
        ...all[index],
        status,
        remarks,
        reviewedBy,
        reviewedAt: new Date().toISOString(),
        currentWorkflowStep: step
      };
      save('applications', all);
      return all[index];
    }
  },

  // DOCUMENTS
  async uploadDocument(applicationId, studentId, documentType, fileName) {
    try {
      const params = new URLSearchParams({ applicationId, studentId, documentType, customFileName: fileName });
      const res = await fetch(`${BASE_URL}/documents/upload?${params.toString()}`, { method: 'POST' });
      if (res.ok) return await res.json();
    } catch (e) {}

    return { id: Date.now(), applicationId, studentId, documentType, fileName };
  }
};
