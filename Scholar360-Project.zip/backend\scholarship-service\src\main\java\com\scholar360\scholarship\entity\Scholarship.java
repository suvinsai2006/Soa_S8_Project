package com.scholar360.scholarship.entity;

import jakarta.persistence.*;
import java.time.LocalDate;

@Entity
@Table(name = "scholarships")
public class Scholarship {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false)
    private String title;

    @Column(length = 2000)
    private String description;

    private String category; // "Merit-Based", "Need-Based", "Women in STEM", "Special Category", "Research Fellowship"
    private String provider; // "Govt of India", "AICTE", "KL University", "Corporate CSR"
    private Double amount;
    private LocalDate deadline;
    private Double minCgpa;
    private Double maxAnnualIncome;
    private String eligibleDepartment; // "ALL" or specific like "Computer Science and Engineering"
    private Integer totalSlots;
    private Integer availableSlots;
    private String status; // "ACTIVE", "CLOSED", "UPCOMING"

    @Column(length = 1000)
    private String requiredDocuments; // comma-separated: "Income Certificate, Grade Sheet, College ID"

    public Scholarship() {}

    public Scholarship(String title, String description, String category, String provider,
                       Double amount, LocalDate deadline, Double minCgpa, Double maxAnnualIncome,
                       String eligibleDepartment, Integer totalSlots, Integer availableSlots,
                       String status, String requiredDocuments) {
        this.title = title;
        this.description = description;
        this.category = category;
        this.provider = provider;
        this.amount = amount;
        this.deadline = deadline;
        this.minCgpa = minCgpa;
        this.maxAnnualIncome = maxAnnualIncome;
        this.eligibleDepartment = eligibleDepartment;
        this.totalSlots = totalSlots;
        this.availableSlots = availableSlots;
        this.status = status;
        this.requiredDocuments = requiredDocuments;
    }

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }
    public String getTitle() { return title; }
    public void setTitle(String title) { this.title = title; }
    public String getDescription() { return description; }
    public void setDescription(String description) { this.description = description; }
    public String getCategory() { return category; }
    public void setCategory(String category) { this.category = category; }
    public String getProvider() { return provider; }
    public void setProvider(String provider) { this.provider = provider; }
    public Double getAmount() { return amount; }
    public void setAmount(Double amount) { this.amount = amount; }
    public LocalDate getDeadline() { return deadline; }
    public void setDeadline(LocalDate deadline) { this.deadline = deadline; }
    public Double getMinCgpa() { return minCgpa; }
    public void setMinCgpa(Double minCgpa) { this.minCgpa = minCgpa; }
    public Double getMaxAnnualIncome() { return maxAnnualIncome; }
    public void setMaxAnnualIncome(Double maxAnnualIncome) { this.maxAnnualIncome = maxAnnualIncome; }
    public String getEligibleDepartment() { return eligibleDepartment; }
    public void setEligibleDepartment(String eligibleDepartment) { this.eligibleDepartment = eligibleDepartment; }
    public Integer getTotalSlots() { return totalSlots; }
    public void setTotalSlots(Integer totalSlots) { this.totalSlots = totalSlots; }
    public Integer getAvailableSlots() { return availableSlots; }
    public void setAvailableSlots(Integer availableSlots) { this.availableSlots = availableSlots; }
    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }
    public String getRequiredDocuments() { return requiredDocuments; }
    public void setRequiredDocuments(String requiredDocuments) { this.requiredDocuments = requiredDocuments; }
}

