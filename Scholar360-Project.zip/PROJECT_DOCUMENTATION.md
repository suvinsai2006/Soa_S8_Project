# Scholar360 – Digital Scholarship Management Platform
## Complete Mini-Project Report & Technical Documentation

> **Course:** SOA PROGRAMMING AND MICROSERVICES (24SDCS03)  
> **Academic Year:** 2026 - 2027  
> **Department:** Department of Computer Science and Engineering  
> **Institution:** K L (Deemed to be University), Bowrampet Campus, Hyderabad  
> **Project Guide:** Dr. G. Neelima (Associate Professor, Dept. of CSE)  
> **Batch:** Batch 18  

---

### Team Members & Allocation

| S.No | Candidate Name | University ID | Branch & Semester | Role in Project |
| :---: | :--- | :---: | :---: | :--- |
| **1** | **G. Suvin Sai** | **2420030115** | B.Tech CSE | Team Lead, Microservices Architecture & Gateway Integration |
| **2** | **P. Lokesh Reddy** | **2420030128** | B.Tech CSE | Backend Services (User & Application Microservices, JPA) |
| **3** | **M. Bhargav** | **2420030124** | B.Tech CSE | Frontend React.js Development, UI Components & API Testing |

---

## Table of Contents

1. [Abstract](#1-abstract)
2. [Introduction & Context](#2-introduction--context)
3. [Literature Survey & Gap Analysis](#3-literature-survey--gap-analysis)
4. [Problem Statement & Objectives](#4-problem-statement--objectives)
5. [Hardware & Software Requirements](#5-hardware--software-requirements)
6. [System Architecture & Implementation](#6-system-architecture--implementation)
   - [6.1 3-Tier Layered Architecture](#61-3-tier-layered-architecture)
   - [6.2 9-Step Governance Workflow](#62-9-step-governance-workflow)
   - [6.3 Microservices Implementation](#63-microservices-implementation)
   - [6.4 Frontend React.js Architecture](#64-frontend-reactjs-architecture)
   - [6.5 REST API Integration Registry](#65-rest-api-integration-registry)
7. [Results & Discussion (with Output Screenshots)](#7-results--discussion)
8. [Conclusion & Future Scope](#8-conclusion--future-scope)
9. [References](#9-references)

---

## 1. Abstract

**Scholar360 – Digital Scholarship Management Platform** is a modern, scalable, and centralized enterprise web application designed to digitize, streamline, and automate the end-to-end higher education scholarship administration lifecycle. Traditional institutional scholarship administration relies predominantly on physical paper applications, manual verification of mark sheets and caste/income certificates, complex criteria validation, and opaque departmental approvals. These legacy procedures cause administrative backlogs, delayed disbursements, human error, and an acute lack of real-time status visibility for applicants.

Scholar360 solves these institutional challenges by applying Service-Oriented Architecture (SOA) and Spring Cloud Microservices principles. The system decomposes business logic into independently deployable domain microservices: User Profile Service, Scholarship Catalog Service, Application Processing Service, Document Management Service, Notification Service, and Administration Audit Service. Service discovery and request routing are handled dynamically through Netflix Eureka Server and Spring Cloud API Gateway. The user layer is powered by a high-performance React.js single-page application with automated eligibility validation and dynamic profile management.

Key operational results demonstrate instantaneous eligibility evaluation, zero-downtime service registration, dynamic student registration/removal, and transparent status tracking across a 9-step governance workflow. The architecture significantly reduces institutional processing cycle times while delivering an intuitive, accessible experience for both students and university administrators.

---

## 2. Introduction & Context

### 2.1 Background
Higher education institutions, government bodies, and charitable foundations disburse billions of rupees annually in merit, need-based, and affirmative-action scholarships. However, connecting deserving students to available endowments remains fragmented. Many qualified candidates miss crucial funding deadlines due to cumbersome offline processes, while financial aid committees struggle to verify student transcripts, caste certifications, and income proofs across thousands of applicants.

### 2.2 Motivation
The motivation behind Scholar360 is to build an open, auditable, and automated digital bridge between university endowments and deserving students. By leveraging Service-Oriented Architecture (SOA), universities can seamlessly connect scholarship disbursement to registrar databases, fee concession accounts, and academic ERPs without building monolithic, fragile codebases.

### 2.3 Key Challenges in Existing Scholarship Systems
- **Manual Eligibility Verification:** Review committees spend hundreds of hours cross-checking minimum CGPA thresholds and family income limits against physical certificates.
- **Opaque Application Status:** Students frequently have zero visibility into whether their application is pending document verification, academic committee review, or financial sanctioning.
- **Single Point of Failure in Monoliths:** Legacy monolithic university portals crash during peak scholarship submission deadlines due to tightly coupled databases.
- **Lack of Dynamic Profile Management:** Inflexible user registries that make it cumbersome to register new candidate cohorts or remove discontinued profiles.

---

## 3. Literature Survey & Gap Analysis

A comprehensive literature survey was conducted across 8 state-of-the-art digital scholarship portals and scholarship management platforms:

1. **National Scholarship Portal (NSP - India):** Government of India's central portal facilitating central and state schemes. While it handles millions of users, its centralized monolithic architecture often faces severe downtime during cutoff dates, and eligibility checks are not real-time.
2. **Buddy4Study Platform:** A private scholarship aggregator in India offering matching algorithms. However, it lacks native integration with university ERP systems and automated fee concession workflows.
3. **Vidyasaarathi Portal (NSDL e-Gov):** An initiative providing CSR fund scholarships. The platform requires extensive manual document upload and manual verification by participating corporate sponsors.
4. **AICTE Pragati & Saksham Schemes:** Dedicated portals for girl students and differently-abled technical students. The portal operates on scheduled batch windows without real-time API communication.
5. **PMSSS (J&K Special Scholarship Portal):** Handles admissions and scholarship allotments through central counseling. Lacks granular microservice modularity for independent scaling of document verifications.
6. **Fastweb Scholarship Directory (USA):** Large-scale commercial database matching students with private grants. Uses third-party redirection rather than an integrated end-to-end institutional workflow.
7. **Scholarships.com Portal:** Public search engine for college financial aid. Focuses purely on discovery without providing administrative evaluation desks or document lifecycle tracking.
8. **Erasmus+ Higher Education System:** European commission exchange portal supporting mobility grants. Excellent in multi-institutional governance but requires complex integration protocols unsuitable for single university campuses.

### Comparative Analysis Table

| Platform | Architecture Style | Persistence | Eligibility Engine | Identified Bottleneck |
| :--- | :--- | :--- | :--- | :--- |
| **National Scholarship Portal (NSP)** | Monolithic / Multi-Tier | Government DB | Offline / Batch | High Server Load During Cutoff Peaks |
| **Buddy4Study** | Client-Server Web | Aggregator DB | Rule-Based | No Direct University Fee Ledger Integration |
| **Vidyasaarathi (NSDL)** | 3-Tier Enterprise | Relational | Manual Sifting | Complex Multi-Stage Document Verification |
| **Scholar360 (Our Platform)** | **SOA & Microservices** | **H2 / MySQL (JPA)** | **Instant Automated Validation** | **Independently Scalable & Dynamic** |

### Problem Gap Identification
Existing portals fail to combine lightweight microservice agility with university-centric governance. Scholar360 bridges this gap by integrating instant criteria validation, dynamic student lifecycle management (adding/removing students dynamically), automated document verification flags, and an interactive 9-step governance workflow into a unified single-page portal.

---

## 4. Problem Statement & Objectives

### 4.1 Problem Statement
> **To design and implement a decentralized, transparent, and scalable digital scholarship management system using Service-Oriented Architecture (SOA) and Spring Boot Microservices that automates eligibility verification, application processing, and multi-tier institutional approvals.**

### 4.2 Problem Description
Conventional university scholarship administration relies on fragmented paper records and rigid monoliths that cause application backlogs, delayed disbursements, human verification errors, and complete opacity for student applicants.

### 4.3 Key Objectives
1. **Modular Microservices Architecture:** Deconstruct scholarship business logic into 6 self-contained Spring Boot microservices with Spring Cloud Gateway and Eureka.
2. **Automated Criteria Validation Engine:** Evaluate student CGPA, annual family income, and academic discipline thresholds dynamically before application submission.
3. **Dynamic Student Registry Management:** Enable instantaneous frontend addition and removal of unlimited student records with automatic backend sync.
4. **9-Step Governance Workflow:** Provide transparent state transitions: Login &rarr; Search &rarr; Eligibility &rarr; Apply &rarr; Docs &rarr; Verification &rarr; Review &rarr; Approval &rarr; Notification.
5. **Unified Responsive Interface:** Deliver clean emerald/teal UI in React.js supporting student application tracking and faculty approval desks.

---

## 5. Hardware & Software Requirements

### 5.1 Hardware Specifications
- **Processor:** Intel Core i5 / i7 (8th Gen or higher) / AMD Ryzen 5
- **RAM:** Minimum 8 GB (16 GB recommended for concurrent microservices execution)
- **Hard Disk:** Minimum 20 GB free space (SSD recommended)
- **Network Interface:** Local loopback network interface (`localhost`)

### 5.2 Software Specifications
- **Operating System:** Windows 10/11 (64-bit), Ubuntu Linux 22.04 LTS, macOS
- **Java Development Kit:** JDK 21 (LTS) / JDK 17
- **Backend Framework:** Spring Boot 3.2.5, Spring Cloud 2023.0.1
- **Frontend Library:** React.js 18.3, Vite 5.4, Lucide React
- **Persistence Layer:** Spring Data JPA, Hibernate, In-Memory H2 Database
- **Build Tools:** Apache Maven 3.9+, Node.js v18+, npm v10+

### 5.3 Microservices Port Allocation Registry

| Service Name | Port | Technology | Purpose |
| :--- | :---: | :--- | :--- |
| **Eureka Discovery Server** | `8761` | Spring Cloud Netflix Eureka | Dynamic service registration & heartbeat monitoring |
| **Spring Cloud API Gateway** | `8080` | Spring Cloud Gateway | Centralized reverse proxy, routing & load balancing |
| **User Management Service** | `8081` | Spring Boot + JPA | Student & admin profiles, role-based auth |
| **Scholarship Catalog Service** | `8082` | Spring Boot + JPA | Scholarship programs, criteria validation engine |
| **Application Management Service** | `8083` | Spring Boot + JPA | Online submissions, status transitions, reviewer remarks |
| **Document Management Service** | `8084` | Spring Boot + JPA | Certificate upload simulation & metadata verification |
| **Notification Service** | `8085` | Spring Boot + JPA | Real-time status notifications & student alerts |
| **Admin & Monitoring Service** | `8086` | Spring Boot + JPA | Aggregated reporting, system metrics, audit logs |
| **Scholar360 Unified Runner** | `8080` | Spring Boot (Merged) | 1-Click all-in-one presentation runner |
| **React.js Web Interface** | `3000` | React.js + Vite | Responsive web interface for Students & Administrators |

---

## 6. System Architecture & Implementation

### 6.1 3-Tier Layered Architecture

```
                         React.js Frontend (Port 3000)
                                      │
                                      ▼ (REST APIs)
                        Spring Cloud Gateway (Port 8080)
                                      │
              ┌───────────────────────┴───────────────────────┐
              ▼                                               ▼
Spring Cloud Eureka Server (:8761)              Distributed Microservices
(Service Discovery Registry)                                  │
                                ┌─────────────────────────────┼─────────────────────────────┐
                                ▼                             ▼                             ▼
                        User Service                  Scholarship Service           Application Service
                           (:8081)                          (:8082)                       (:8083)
                                │                             │                             │
                                └─────────────────────────────┼─────────────────────────────┘
                                                              ▼
                                ┌─────────────────────────────┼─────────────────────────────┐
                                ▼                             ▼                             ▼
                        Document Service              Notification Service          Admin & Monitoring
                           (:8084)                          (:8085)                       (:8086)
                                                              │
                                                              ▼
                                                  Relational Database (H2)
```

### 6.2 9-Step Governance Workflow

```
[1. Login & Auth] ──> [2. Discovery] ──> [3. Eligibility Check] ──> [4. Application]
       │
       └───> [5. Documents] ──> [6. Verification] ──> [7. Review] ──> [8. Approval] ──> [9. Notification]
```

1. **Login & Auth:** Student authenticates profile with University ID and role permissions.
2. **Discovery:** Browse active scholarship programs filtered by title or category.
3. **Eligibility Check:** Automated rules engine checks candidate CGPA and income.
4. **Application:** Online application draft and submission through Application Service.
5. **Documents Upload:** Attaching supporting income certificates and academic transcripts.
6. **Verification:** Automated or clerical validation of uploaded document hashes.
7. **Academic Review:** Faculty committee assessment of student credentials.
8. **Approval:** Final sanctioning of fee concession or scholarship fund allocation.
9. **Notification:** Dispatch of real-time approval decision and student dashboard update.

### 6.3 REST API Integration Registry

| Method | Endpoint Path | Source Service | Functional Role |
| :---: | :--- | :--- | :--- |
| `POST` | `/api/users/register` | User Service | Registers a new student dynamically into database |
| `GET` | `/api/users/students` | User Service | Fetches all registered student profiles |
| `DELETE` | `/api/users/{id}` | User Service | Deletes a student from system database |
| `GET` | `/api/scholarships` | Scholarship Service | Returns full catalog of active scholarship programs |
| `POST` | `/api/scholarships/{id}/check-eligibility` | Scholarship Service | Evaluates applicant CGPA and income limits in real-time |
| `POST` | `/api/applications/apply` | Application Service | Submits scholarship application payload |
| `GET` | `/api/applications/student/{id}` | Application Service | Retrieves submitted applications for active student |
| `PUT` | `/api/applications/{id}/status` | Application Service | Faculty approval or rejection with remarks |
| `GET` | `/api/admin/system-health` | Admin Service | System heartbeat and active service health metrics |

---

## 7. Results & Discussion

### 7.1 Verified Application Screen Outputs

![Figure 7.1: Live Application Interface](output_screenshot.png)

* **Figure 7.1:** *Live Scholar360 Application Interface running on `http://localhost:3000` showing the 3-tier Service-Oriented Architecture, Spring Cloud Gateway (:8080) and Eureka Server (:8761) orchestration, and the 9-Step Application Lifecycle Workflow.*

### 7.2 Detailed Functional Demonstrations

1. **System Architecture & Workflow View (Figure 7.1):**
   Displays the complete decoupled architecture from the React.js client down to the relational storage layer. The bottom interactive workflow tracks the 9 distinct lifecycle stages.

2. **Student Portal & Instant Criteria Checker:**
   Students review their CGPA, University ID, and Annual Family Income directly on the top banner. Clicking **Check Eligibility** triggers instant criteria validation against backend thresholds, rendering a green `Eligible` badge or detailed red requirements feedback.

3. **Unlimited Student Addition (`+ Add Student`):**
   The registration modal dynamically computes the next available student (e.g. `Student 4`, `Student 5`, ... `Student N`) with unique University IDs, preventing database collisions. Includes a **+ Save & Add Another** button and **Auto Generate** batch actions (+2, +3, +5, +10 students).

4. **Instant Student Deletion (`Remove Student`):**
   Students can be deleted with one click:
   - Directly from the **Student Portal Profile Header**
   - Directly from the **Top Navigation Bar** beside the active profile
   - Directly from the **Manage Students Directory** in the Admin Portal
   - From the **Remove Students** tab inside the management modal

5. **Faculty & Administration Evaluation Desk:**
   Administrators can review submitted dossiers, verify applicant CGPA and family income certificates, and grant 1-click approvals or rejections, updating total disbursed fee concessions dynamically.

---

## 8. Conclusion & Future Scope

### 8.1 Conclusion
The development of Scholar360 successfully fulfills all objectives set forth in the Service-Oriented Architecture (SOA) and Microservices course curriculum (24SDCS03). The platform eliminates traditional paper-based application delays, reduces verification friction, and provides an auditable, transparent digital framework for modern educational institutions.

By combining Spring Boot 3.2.5, Spring Cloud Gateway, Eureka Service Discovery, and React.js, the project proves the operational superiority of decentralized microservices over rigid legacy monoliths. The dynamic student registration and deletion features, coupled with instant eligibility validation, ensure high usability, performance, and institutional scalability.

### 8.2 Future Scope
- **Near-Term Scope (AI Matching Engine):** Integrating machine learning algorithms to automatically recommend specialized private endowments and corporate CSR grants based on student skill portfolios.
- **Medium-Term Scope (Blockchain Credential Verification):** Deploying smart contracts on Polygon / Ethereum testnets to anchor caste and income certificates on-chain, preventing document forgery.
- **Long-Term Scope (Mobile App & Native Bank Integration):** Developing Flutter / React Native mobile applications with direct DBT (Direct Benefit Transfer) integration to nationalized bank accounts.

---

## 9. References

1. National Scholarship Portal (NSP), Government of India. Official Portal: [https://scholarships.gov.in/](https://scholarships.gov.in/)
2. Buddy4Study – India's Largest Scholarship Network. Available at: [https://www.buddy4study.com/](https://www.buddy4study.com/)
3. Vidyasaarathi Education Scholarship Portal, NSDL e-Governance Infrastructure. Available at: [https://www.vidyasaarathi.co.in/](https://www.vidyasaarathi.co.in/)
4. All India Council for Technical Education (AICTE) Pragati & Saksham Schemes. Available at: [https://www.aicte-india.org/schemes/students-development-schemes](https://www.aicte-india.org/schemes/students-development-schemes)
5. Prime Minister's Special Scholarship Scheme (PMSSS) for J&K and Ladakh. Available at: [https://www.aicte-jk-scholarship-gov.in/](https://www.aicte-jk-scholarship-gov.in/)
6. Fastweb Scholarship Discovery & Financial Aid Directory (USA). Available at: [https://www.fastweb.com/](https://www.fastweb.com/)
7. Scholarships.com – Free College Scholarship Search and Financial Aid Resource. Available at: [https://www.scholarships.com/](https://www.scholarships.com/)
8. Spring Boot Reference Documentation (v3.2.5). VMware Tanzu / Spring IO: [https://docs.spring.io/spring-boot/docs/current/reference/html/](https://docs.spring.io/spring-boot/docs/current/reference/html/)
9. Spring Cloud Netflix Eureka & Gateway Documentation (2023.0.1). Available at: [https://spring.io/projects/spring-cloud](https://spring.io/projects/spring-cloud)
10. React.js Official Documentation (v18.3) – Building Interactive User Interfaces. Available at: [https://react.dev/](https://react.dev/)
11. Martin Fowler (2014), "Microservices: A definition of this new architectural term", ThoughtWorks Software Development Guide: [https://martinfowler.com/articles/microservices.html](https://martinfowler.com/articles/microservices.html)
12. Erl, Thomas (2005), "Service-Oriented Architecture: Concepts, Technology, and Design", Prentice Hall PTR.
