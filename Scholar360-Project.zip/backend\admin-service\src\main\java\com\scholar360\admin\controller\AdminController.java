package com.scholar360.admin.controller;

import com.scholar360.admin.entity.AuditLog;
import com.scholar360.admin.repository.AuditLogRepository;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.*;

@RestController
@RequestMapping("/api/admin")
@CrossOrigin(origins = "*")
public class AdminController {

    private final AuditLogRepository auditLogRepository;

    public AdminController(AuditLogRepository auditLogRepository) {
        this.auditLogRepository = auditLogRepository;
    }

    @GetMapping("/audit-logs")
    public List<AuditLog> getAuditLogs() {
        return auditLogRepository.findTop20ByOrderByTimestampDesc();
    }

    @PostMapping("/audit-logs")
    public ResponseEntity<AuditLog> logAction(@RequestBody AuditLog log) {
        AuditLog saved = auditLogRepository.save(log);
        return ResponseEntity.ok(saved);
    }

    @GetMapping("/dashboard-stats")
    public Map<String, Object> getDashboardStats() {
        Map<String, Object> stats = new HashMap<>();
        stats.put("totalStudents", 3);
        stats.put("totalScholarships", 5);
        stats.put("activeScholarships", 5);
        stats.put("totalApplications", 3);
        stats.put("approvedApplications", 1);
        stats.put("underReviewApplications", 1);
        stats.put("docsVerifiedApplications", 1);
        stats.put("totalDisbursedFunds", 40000.0);
        stats.put("pendingVerificationDocuments", 1);
        stats.put("systemHealth", "OPTIMAL");
        return stats;
    }

    @GetMapping("/system-health")
    public Map<String, Object> getSystemHealth() {
        Map<String, Object> health = new HashMap<>();
        health.put("status", "UP");
        health.put("services", List.of(
                Map.of("name", "User Management Service", "port", 8081, "status", "ONLINE"),
                Map.of("name", "Scholarship Management Service", "port", 8082, "status", "ONLINE"),
                Map.of("name", "Application Management Service", "port", 8083, "status", "ONLINE"),
                Map.of("name", "Document Management Service", "port", 8084, "status", "ONLINE"),
                Map.of("name", "Notification Service", "port", 8085, "status", "ONLINE"),
                Map.of("name", "Administration & Monitoring Service", "port", 8086, "status", "ONLINE")
        ));
        return health;
    }
}

