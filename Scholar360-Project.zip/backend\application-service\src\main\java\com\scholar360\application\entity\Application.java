package com.scholar360.application.entity;

import jakarta.persistence.*;
import java.time.LocalDateTime;

@Entity
@Table(name = "applications")
public class Application {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false)
    private Long studentId;

    private String studentName;
    private String studentEmail;
    private String studentRollNumber;
    private String studentDepartment;
    private Double studentCgpa;
    private Double annualFamilyIncome;

    @Column(nullable = false)
    private Long scholarshipId;

    private String scholarshipTitle;
    private Double scholarshipAmount;

    private LocalDateTime submissionDate = LocalDateTime.now();

    // SUBMITTED, UNDER_REVIEW, DOCS_VERIFIED, APPROVED, REJECTED
    @Column(nullable = false)
    private String status = "SUBMITTED";

    @Column(length = 2000)
    private String remarks;

    private String reviewedBy;
    private LocalDateTime reviewedAt;

    public Application() {}

    public Application(Long studentId, String studentName, String studentEmail, String studentRollNumber,
                       String studentDepartment, Double studentCgpa, Double annualFamilyIncome,
                       Long scholarshipId, String scholarshipTitle, Double scholarshipAmount,
                       String status, String remarks) {
        this.studentId = studentId;
        this.studentName = studentName;
        this.studentEmail = studentEmail;
        this.studentRollNumber = studentRollNumber;
        this.studentDepartment = studentDepartment;
        this.studentCgpa = studentCgpa;
        this.annualFamilyIncome = annualFamilyIncome;
        this.scholarshipId = scholarshipId;
        this.scholarshipTitle = scholarshipTitle;
        this.scholarshipAmount = scholarshipAmount;
        this.status = status;
        this.remarks = remarks;
        this.submissionDate = LocalDateTime.now();
    }

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }
    public Long getStudentId() { return studentId; }
    public void setStudentId(Long studentId) { this.studentId = studentId; }
    public String getStudentName() { return studentName; }
    public void setStudentName(String studentName) { this.studentName = studentName; }
    public String getStudentEmail() { return studentEmail; }
    public void setStudentEmail(String studentEmail) { this.studentEmail = studentEmail; }
    public String getStudentRollNumber() { return studentRollNumber; }
    public void setStudentRollNumber(String studentRollNumber) { this.studentRollNumber = studentRollNumber; }
    public String getStudentDepartment() { return studentDepartment; }
    public void setStudentDepartment(String studentDepartment) { this.studentDepartment = studentDepartment; }
    public Double getStudentCgpa() { return studentCgpa; }
    public void setStudentCgpa(Double studentCgpa) { this.studentCgpa = studentCgpa; }
    public Double getAnnualFamilyIncome() { return annualFamilyIncome; }
    public void setAnnualFamilyIncome(Double annualFamilyIncome) { this.annualFamilyIncome = annualFamilyIncome; }
    public Long getScholarshipId() { return scholarshipId; }
    public void setScholarshipId(Long scholarshipId) { this.scholarshipId = scholarshipId; }
    public String getScholarshipTitle() { return scholarshipTitle; }
    public void setScholarshipTitle(String scholarshipTitle) { this.scholarshipTitle = scholarshipTitle; }
    public Double getScholarshipAmount() { return scholarshipAmount; }
    public void setScholarshipAmount(Double scholarshipAmount) { this.scholarshipAmount = scholarshipAmount; }
    public LocalDateTime getSubmissionDate() { return submissionDate; }
    public void setSubmissionDate(LocalDateTime submissionDate) { this.submissionDate = submissionDate; }
    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }
    public String getRemarks() { return remarks; }
    public void setRemarks(String remarks) { this.remarks = remarks; }
    public String getReviewedBy() { return reviewedBy; }
    public void setReviewedBy(String reviewedBy) { this.reviewedBy = reviewedBy; }
    public LocalDateTime getReviewedAt() { return reviewedAt; }
    public void setReviewedAt(LocalDateTime reviewedAt) { this.reviewedAt = reviewedAt; }
}

