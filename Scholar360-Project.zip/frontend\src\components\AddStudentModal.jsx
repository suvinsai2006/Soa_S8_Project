import React, { useState, useEffect } from 'react';
import { X, UserPlus, UserCheck, Layers, Sparkles, Trash2 } from 'lucide-react';

function getNextStudentDefaults(studentsList = []) {
  let max = 0;
  studentsList.forEach(s => {
    const m = s.fullName && s.fullName.match(/Student\s+(\d+)/i);
    if (m) {
      const val = parseInt(m[1], 10);
      if (val > max) max = val;
    }
  });
  let next = max > 0 ? max + 1 : (studentsList.length || 0) + 1;

  while (studentsList.some(s => s.email === `student${next}@univ.edu` || s.rollNumber === `2420030${100 + next}`)) {
    next++;
  }

  const categories = ['General', 'OBC', 'SC', 'ST', 'EWS'];
  const cat = categories[(next - 1) % categories.length];
  const baseCgpa = 7.6 + ((next * 3) % 22) * 0.1;
  const cgpa = Number(Math.min(9.85, Math.max(7.2, baseCgpa)).toFixed(2));
  const income = 220000 + ((next * 5) % 9) * 40000;

  return {
    fullName: `Student ${next}`,
    rollNumber: `2420030${100 + next}`,
    email: `student${next}@univ.edu`,
    department: 'Computer Science and Engineering',
    cgpa,
    annualFamilyIncome: income,
    category: cat,
    password: 'student123',
    phone: `+91 98765${String(40000 + next).slice(-5)}`
  };
}

export default function AddStudentModal({ 
  isOpen, 
  onClose, 
  onAddStudent, 
  onDeleteStudent,
  students = [] 
}) {
  const [modalTab, setModalTab] = useState('add'); // 'add' or 'manage'
  const [formData, setFormData] = useState(() => getNextStudentDefaults(students));
  const [loading, setLoading] = useState(false);
  const [successMsg, setSuccessMsg] = useState('');
  const [batchCount, setBatchCount] = useState(3);

  // Sync state whenever modal opens or students list updates
  useEffect(() => {
    if (isOpen) {
      setFormData(getNextStudentDefaults(students));
      setSuccessMsg('');
    }
  }, [isOpen, students.length]);

  if (!isOpen) return null;

  const handleSubmit = async (e, addAnother = false) => {
    if (e) e.preventDefault();
    setLoading(true);
    setSuccessMsg('');
    try {
      const created = await onAddStudent({
        ...formData,
        cgpa: parseFloat(formData.cgpa),
        annualFamilyIncome: parseFloat(formData.annualFamilyIncome)
      });

      if (addAnother) {
        setSuccessMsg(`✓ Added ${formData.fullName}! Ready for next student.`);
        // Immediately generate next student defaults
        const updatedList = [...students, { ...formData, id: Date.now() }];
        setFormData(getNextStudentDefaults(updatedList));
      } else {
        onClose();
      }
    } catch (err) {
      console.error('Error adding student:', err);
    } finally {
      setLoading(false);
    }
  };

  const handleQuickBatch = async () => {
    setLoading(true);
    try {
      let currentList = [...students];
      for (let i = 0; i < batchCount; i++) {
        const nextDefaults = getNextStudentDefaults(currentList);
        await onAddStudent({
          ...nextDefaults,
          cgpa: parseFloat(nextDefaults.cgpa),
          annualFamilyIncome: parseFloat(nextDefaults.annualFamilyIncome)
        });
        currentList.push({ ...nextDefaults, id: Date.now() + i });
      }
      setSuccessMsg(`✓ Successfully generated ${batchCount} students!`);
      setTimeout(() => {
        onClose();
      }, 1000);
    } catch (err) {
      console.error('Batch error:', err);
    } finally {
      setLoading(false);
    }
  };

  const handleRemove = async (student) => {
    if (window.confirm(`Are you sure you want to remove ${student.fullName} (University ID: ${student.rollNumber})?`)) {
      onDeleteStudent && onDeleteStudent(student.id);
    }
  };

  return (
    <div style={{
      position: 'fixed',
      top: 0,
      left: 0,
      right: 0,
      bottom: 0,
      background: 'rgba(15, 23, 42, 0.5)',
      backdropFilter: 'blur(3px)',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      zIndex: 100,
      padding: '20px'
    }}>
      <div className="card" style={{ maxWidth: '540px', width: '100%', padding: '24px', background: '#ffffff', borderRadius: '14px', maxHeight: '90vh', overflowY: 'auto' }}>
        
        {/* Modal Header */}
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '14px' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
            <div style={{
              width: '36px',
              height: '36px',
              borderRadius: '8px',
              background: '#f0fdfa',
              border: '1px solid #99f6e4',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              color: '#0d9488'
            }}>
              <UserPlus size={20} />
            </div>
            <div>
              <h3 style={{ fontSize: '17px', fontWeight: 800, color: '#0f172a' }}>Student Management</h3>
              <p style={{ fontSize: '12px', color: '#64748b' }}>
                Add new students or remove existing students ({students.length} currently enrolled).
              </p>
            </div>
          </div>
          <button 
            onClick={onClose} 
            style={{ background: 'none', border: 'none', cursor: 'pointer', color: '#64748b', padding: '4px' }}
          >
            <X size={20} />
          </button>
        </div>

        {/* Tab Toggle: Add vs Remove / Manage */}
        <div style={{ display: 'flex', gap: '8px', marginBottom: '16px', background: '#f1f5f9', padding: '3px', borderRadius: '8px' }}>
          <button
            type="button"
            onClick={() => setModalTab('add')}
            style={{
              flex: 1,
              padding: '6px 12px',
              borderRadius: '6px',
              border: 'none',
              fontWeight: 700,
              fontSize: '12px',
              cursor: 'pointer',
              background: modalTab === 'add' ? '#ffffff' : 'transparent',
              color: modalTab === 'add' ? '#0d9488' : '#64748b',
              boxShadow: modalTab === 'add' ? '0 1px 3px rgba(0,0,0,0.08)' : 'none'
            }}
          >
            + Register New Student
          </button>
          <button
            type="button"
            onClick={() => setModalTab('manage')}
            style={{
              flex: 1,
              padding: '6px 12px',
              borderRadius: '6px',
              border: 'none',
              fontWeight: 700,
              fontSize: '12px',
              cursor: 'pointer',
              background: modalTab === 'manage' ? '#ffffff' : 'transparent',
              color: modalTab === 'manage' ? '#e11d48' : '#64748b',
              boxShadow: modalTab === 'manage' ? '0 1px 3px rgba(0,0,0,0.08)' : 'none'
            }}
          >
            Remove Students ({students.length})
          </button>
        </div>

        {/* Success Alert Banner */}
        {successMsg && (
          <div style={{
            background: '#f0fdf4',
            border: '1px solid #bbf7d0',
            color: '#16a34a',
            padding: '8px 12px',
            borderRadius: '8px',
            fontSize: '12px',
            fontWeight: 600,
            marginBottom: '12px'
          }}>
            {successMsg}
          </div>
        )}

        {/* REMOVE / MANAGE STUDENTS TAB */}
        {modalTab === 'manage' && (
          <div>
            <div style={{ maxHeight: '340px', overflowY: 'auto', display: 'flex', flexDirection: 'column', gap: '8px' }}>
              {students.length === 0 ? (
                <div style={{ textAlign: 'center', padding: '20px', color: '#64748b', fontSize: '13px' }}>
                  No students currently registered. Use "+ Register New Student" to add.
                </div>
              ) : (
                students.map(s => (
                  <div
                    key={s.id}
                    style={{
                      display: 'flex',
                      alignItems: 'center',
                      justifyContent: 'space-between',
                      padding: '10px 14px',
                      background: '#f8fafc',
                      border: '1px solid #e2e8f0',
                      borderRadius: '8px',
                      gap: '10px'
                    }}
                  >
                    <div style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
                      <div style={{
                        width: '32px',
                        height: '32px',
                        borderRadius: '6px',
                        background: '#f0fdfa',
                        color: '#0d9488',
                        border: '1px solid #99f6e4',
                        fontWeight: 700,
                        fontSize: '12px',
                        display: 'flex',
                        alignItems: 'center',
                        justifyContent: 'center'
                      }}>
                        {s.avatar || s.fullName.substring(0, 2).toUpperCase()}
                      </div>
                      <div>
                        <div style={{ fontWeight: 700, color: '#0f172a', fontSize: '13px' }}>{s.fullName}</div>
                        <div style={{ fontSize: '11px', color: '#64748b' }}>
                          University ID: <strong>{s.rollNumber}</strong> • CGPA: {s.cgpa}
                        </div>
                      </div>
                    </div>

                    <button
                      type="button"
                      onClick={() => handleRemove(s)}
                      className="btn btn-danger btn-sm"
                      style={{ padding: '4px 10px', fontSize: '11px', display: 'flex', alignItems: 'center', gap: '4px' }}
                      title="Remove this student"
                    >
                      <Trash2 size={12} /> Remove
                    </button>
                  </div>
                ))
              )}
            </div>

            <div style={{ display: 'flex', justifyContent: 'flex-end', marginTop: '16px' }}>
              <button type="button" onClick={onClose} className="btn btn-secondary btn-sm">
                Done
              </button>
            </div>
          </div>
        )}

        {/* ADD STUDENT TAB */}
        {modalTab === 'add' && (
          <form onSubmit={(e) => handleSubmit(e, false)} style={{ display: 'flex', flexDirection: 'column', gap: '12px' }}>
            
            <div style={{ display: 'grid', gridTemplateColumns: '1.2fr 1fr', gap: '10px' }}>
              <div>
                <label style={{ fontSize: '11px', fontWeight: 700, display: 'block', marginBottom: '4px', color: '#334155' }}>
                  Full Name
                </label>
                <input
                  type="text"
                  required
                  className="input"
                  placeholder="Student Name"
                  value={formData.fullName}
                  onChange={(e) => setFormData({ ...formData, fullName: e.target.value })}
                />
              </div>
              <div>
                <label style={{ fontSize: '11px', fontWeight: 700, display: 'block', marginBottom: '4px', color: '#334155' }}>
                  University ID
                </label>
                <input
                  type="text"
                  required
                  className="input"
                  placeholder="e.g. 2420030130"
                  value={formData.rollNumber}
                  onChange={(e) => setFormData({ ...formData, rollNumber: e.target.value })}
                />
              </div>
            </div>

            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '10px' }}>
              <div>
                <label style={{ fontSize: '11px', fontWeight: 700, display: 'block', marginBottom: '4px', color: '#334155' }}>
                  Email
                </label>
                <input
                  type="email"
                  required
                  className="input"
                  value={formData.email}
                  onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                />
              </div>
              <div>
                <label style={{ fontSize: '11px', fontWeight: 700, display: 'block', marginBottom: '4px', color: '#334155' }}>
                  Category
                </label>
                <select
                  className="select"
                  value={formData.category}
                  onChange={(e) => setFormData({ ...formData, category: e.target.value })}
                >
                  <option value="General">General</option>
                  <option value="OBC">OBC</option>
                  <option value="SC">SC</option>
                  <option value="ST">ST</option>
                  <option value="EWS">EWS</option>
                </select>
              </div>
            </div>

            <div>
              <label style={{ fontSize: '11px', fontWeight: 700, display: 'block', marginBottom: '4px', color: '#334155' }}>
                Department
              </label>
              <input
                type="text"
                required
                className="input"
                value={formData.department}
                onChange={(e) => setFormData({ ...formData, department: e.target.value })}
              />
            </div>

            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1.2fr', gap: '10px' }}>
              <div>
                <label style={{ fontSize: '11px', fontWeight: 700, display: 'block', marginBottom: '4px', color: '#334155' }}>
                  CGPA (0 - 10)
                </label>
                <input
                  type="number"
                  step="0.01"
                  min="0"
                  max="10"
                  required
                  className="input"
                  value={formData.cgpa}
                  onChange={(e) => setFormData({ ...formData, cgpa: e.target.value })}
                />
              </div>
              <div>
                <label style={{ fontSize: '11px', fontWeight: 700, display: 'block', marginBottom: '4px', color: '#334155' }}>
                  Annual Income (₹)
                </label>
                <input
                  type="number"
                  step="5000"
                  required
                  className="input"
                  value={formData.annualFamilyIncome}
                  onChange={(e) => setFormData({ ...formData, annualFamilyIncome: e.target.value })}
                />
              </div>
            </div>

            {/* Quick Actions Bar */}
            <div style={{
              background: '#f8fafc',
              border: '1px dashed #cbd5e1',
              borderRadius: '10px',
              padding: '12px',
              marginTop: '4px',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'space-between',
              flexWrap: 'wrap',
              gap: '8px'
            }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: '6px', fontSize: '11px', color: '#64748b' }}>
                <Sparkles size={14} color="#0d9488" />
                <span>Need multiple test students quickly?</span>
              </div>
              <div style={{ display: 'flex', alignItems: 'center', gap: '6px' }}>
                <select
                  value={batchCount}
                  onChange={(e) => setBatchCount(Number(e.target.value))}
                  className="select"
                  style={{ padding: '3px 8px', fontSize: '11px', width: 'auto' }}
                >
                  <option value={2}>+2 Students</option>
                  <option value={3}>+3 Students</option>
                  <option value={5}>+5 Students</option>
                  <option value={10}>+10 Students</option>
                </select>
                <button
                  type="button"
                  onClick={handleQuickBatch}
                  disabled={loading}
                  className="btn btn-secondary btn-sm"
                  style={{ padding: '4px 10px', fontSize: '11px' }}
                >
                  Auto Generate
                </button>
              </div>
            </div>

            <div style={{
              background: '#f0fdfa',
              padding: '8px 12px',
              borderRadius: '8px',
              fontSize: '11px',
              color: '#0f766e',
              display: 'flex',
              alignItems: 'center',
              gap: '6px'
            }}>
              <UserCheck size={14} />
              <span>Persisted automatically in the User Microservice database and local session.</span>
            </div>

            {/* Modal Footer Buttons */}
            <div style={{ display: 'flex', justifyContent: 'flex-end', gap: '8px', marginTop: '8px', flexWrap: 'wrap' }}>
              <button 
                type="button" 
                onClick={onClose} 
                className="btn btn-secondary btn-sm"
                disabled={loading}
              >
                Cancel
              </button>
              <button 
                type="button" 
                onClick={(e) => handleSubmit(e, true)}
                className="btn btn-secondary btn-sm"
                style={{ borderColor: '#0d9488', color: '#0d9488' }}
                disabled={loading}
              >
                + Save &amp; Add Another
              </button>
              <button 
                type="submit" 
                className="btn btn-primary btn-sm"
                disabled={loading}
              >
                {loading ? 'Adding...' : 'Save & Close'}
              </button>
            </div>
          </form>
        )}

      </div>
    </div>
  );
}
