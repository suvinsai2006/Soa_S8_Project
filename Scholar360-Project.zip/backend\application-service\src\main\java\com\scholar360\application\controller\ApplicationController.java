package com.scholar360.application.controller;

import com.scholar360.application.entity.Application;
import com.scholar360.application.repository.ApplicationRepository;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDateTime;
import java.util.*;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/api/applications")
@CrossOrigin(origins = "*")
public class ApplicationController {

    private final ApplicationRepository applicationRepository;

    public ApplicationController(ApplicationRepository applicationRepository) {
        this.applicationRepository = applicationRepository;
    }

    @PostMapping("/apply")
    public ResponseEntity<?> apply(@RequestBody Application application) {
        // Prevent duplicate active application for same scholarship by same student
        List<Application> existing = applicationRepository.findByStudentId(application.getStudentId());
        boolean alreadyApplied = existing.stream().anyMatch(a ->
                a.getScholarshipId().equals(application.getScholarshipId()) &&
                !a.getStatus().equals("REJECTED")
        );
        if (alreadyApplied) {
            return ResponseEntity.badRequest().body(Map.of("error", "You have already applied for this scholarship"));
        }

        application.setStatus("SUBMITTED");
        application.setSubmissionDate(LocalDateTime.now());
        Application saved = applicationRepository.save(application);
        return ResponseEntity.ok(saved);
    }

    @GetMapping("/student/{studentId}")
    public List<Application> getByStudentId(@PathVariable Long studentId) {
        return applicationRepository.findByStudentId(studentId);
    }

    @GetMapping("/{id}")
    public ResponseEntity<Application> getById(@PathVariable Long id) {
        return applicationRepository.findById(id)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    @GetMapping
    public List<Application> getAll(
            @RequestParam(required = false) String status,
            @RequestParam(required = false) Long scholarshipId) {
        List<Application> list = applicationRepository.findAll();
        if (status != null && !status.isBlank() && !status.equalsIgnoreCase("ALL")) {
            list = list.stream().filter(a -> a.getStatus().equalsIgnoreCase(status)).collect(Collectors.toList());
        }
        if (scholarshipId != null) {
            list = list.stream().filter(a -> a.getScholarshipId().equals(scholarshipId)).collect(Collectors.toList());
        }
        return list;
    }

    @PutMapping("/{id}/status")
    public ResponseEntity<?> updateStatus(@PathVariable Long id, @RequestBody Map<String, String> payload) {
        String newStatus = payload.get("status");
        String remarks = payload.get("remarks");
        String reviewedBy = payload.get("reviewedBy");

        return applicationRepository.findById(id).map(app -> {
            if (newStatus != null) app.setStatus(newStatus);
            if (remarks != null) app.setRemarks(remarks);
            if (reviewedBy != null) app.setReviewedBy(reviewedBy);
            app.setReviewedAt(LocalDateTime.now());
            Application saved = applicationRepository.save(app);
            return ResponseEntity.ok(saved);
        }).orElse(ResponseEntity.notFound().build());
    }

    @GetMapping("/stats")
    public Map<String, Object> getStats() {
        List<Application> all = applicationRepository.findAll();
        Map<String, Object> stats = new HashMap<>();
        stats.put("total", all.size());
        stats.put("submitted", all.stream().filter(a -> "SUBMITTED".equalsIgnoreCase(a.getStatus())).count());
        stats.put("underReview", all.stream().filter(a -> "UNDER_REVIEW".equalsIgnoreCase(a.getStatus())).count());
        stats.put("docsVerified", all.stream().filter(a -> "DOCS_VERIFIED".equalsIgnoreCase(a.getStatus())).count());
        stats.put("approved", all.stream().filter(a -> "APPROVED".equalsIgnoreCase(a.getStatus())).count());
        stats.put("rejected", all.stream().filter(a -> "REJECTED".equalsIgnoreCase(a.getStatus())).count());

        double totalDisbursed = all.stream()
                .filter(a -> "APPROVED".equalsIgnoreCase(a.getStatus()) && a.getScholarshipAmount() != null)
                .mapToDouble(Application::getScholarshipAmount)
                .sum();
        stats.put("totalDisbursedAmount", totalDisbursed);

        return stats;
    }
}

