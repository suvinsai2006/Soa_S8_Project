package com.scholar360.admin;

import com.scholar360.admin.entity.AuditLog;
import com.scholar360.admin.repository.AuditLogRepository;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;
import org.springframework.context.annotation.Bean;

@SpringBootApplication
@EnableDiscoveryClient
public class AdminServiceApplication {

    public static void main(String[] args) {
        SpringApplication.run(AdminServiceApplication.class, args);
    }

    @Bean
    CommandLineRunner initLogs(AuditLogRepository repo) {
        return args -> {
            if (repo.count() == 0) {
                repo.save(new AuditLog("APPLICATION_APPROVED", "Faculty Administrator", "App #2 (Student 2)", "Approved Chancellor's Merit Award."));
                repo.save(new AuditLog("DOCUMENT_VERIFIED", "Verification Officer", "App #1 (Student 1)", "Income Certificate verified against State Database."));
            }
        };
    }
}
