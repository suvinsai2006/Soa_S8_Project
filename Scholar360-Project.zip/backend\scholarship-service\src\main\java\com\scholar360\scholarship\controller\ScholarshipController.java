package com.scholar360.scholarship.controller;

import com.scholar360.scholarship.entity.Scholarship;
import com.scholar360.scholarship.repository.ScholarshipRepository;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;
import java.util.*;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/api/scholarships")
@CrossOrigin(origins = "*")
public class ScholarshipController {

    private final ScholarshipRepository scholarshipRepository;

    public ScholarshipController(ScholarshipRepository scholarshipRepository) {
        this.scholarshipRepository = scholarshipRepository;
    }

    @GetMapping
    public List<Scholarship> getAllScholarships(
            @RequestParam(required = false) String search,
            @RequestParam(required = false) String category,
            @RequestParam(required = false) String status) {

        List<Scholarship> list = scholarshipRepository.findAll();

        if (status != null && !status.isBlank()) {
            list = list.stream().filter(s -> s.getStatus().equalsIgnoreCase(status)).collect(Collectors.toList());
        }
        if (category != null && !category.isBlank() && !category.equalsIgnoreCase("ALL")) {
            list = list.stream().filter(s -> s.getCategory().equalsIgnoreCase(category)).collect(Collectors.toList());
        }
        if (search != null && !search.isBlank()) {
            String lower = search.toLowerCase();
            list = list.stream().filter(s ->
                    s.getTitle().toLowerCase().contains(lower) ||
                    (s.getDescription() != null && s.getDescription().toLowerCase().contains(lower)) ||
                    (s.getProvider() != null && s.getProvider().toLowerCase().contains(lower))
            ).collect(Collectors.toList());
        }
        return list;
    }

    @GetMapping("/{id}")
    public ResponseEntity<Scholarship> getById(@PathVariable Long id) {
        return scholarshipRepository.findById(id)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    @PostMapping
    public ResponseEntity<Scholarship> create(@RequestBody Scholarship scholarship) {
        if (scholarship.getStatus() == null) scholarship.setStatus("ACTIVE");
        if (scholarship.getAvailableSlots() == null) scholarship.setAvailableSlots(scholarship.getTotalSlots());
        Scholarship saved = scholarshipRepository.save(scholarship);
        return ResponseEntity.ok(saved);
    }

    @PutMapping("/{id}")
    public ResponseEntity<Scholarship> update(@PathVariable Long id, @RequestBody Scholarship updated) {
        return scholarshipRepository.findById(id).map(s -> {
            if (updated.getTitle() != null) s.setTitle(updated.getTitle());
            if (updated.getDescription() != null) s.setDescription(updated.getDescription());
            if (updated.getCategory() != null) s.setCategory(updated.getCategory());
            if (updated.getProvider() != null) s.setProvider(updated.getProvider());
            if (updated.getAmount() != null) s.setAmount(updated.getAmount());
            if (updated.getDeadline() != null) s.setDeadline(updated.getDeadline());
            if (updated.getMinCgpa() != null) s.setMinCgpa(updated.getMinCgpa());
            if (updated.getMaxAnnualIncome() != null) s.setMaxAnnualIncome(updated.getMaxAnnualIncome());
            if (updated.getEligibleDepartment() != null) s.setEligibleDepartment(updated.getEligibleDepartment());
            if (updated.getTotalSlots() != null) s.setTotalSlots(updated.getTotalSlots());
            if (updated.getAvailableSlots() != null) s.setAvailableSlots(updated.getAvailableSlots());
            if (updated.getStatus() != null) s.setStatus(updated.getStatus());
            if (updated.getRequiredDocuments() != null) s.setRequiredDocuments(updated.getRequiredDocuments());
            return ResponseEntity.ok(scholarshipRepository.save(s));
        }).orElse(ResponseEntity.notFound().build());
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<?> delete(@PathVariable Long id) {
        if (scholarshipRepository.existsById(id)) {
            scholarshipRepository.deleteById(id);
            return ResponseEntity.ok(Map.of("message", "Scholarship deleted successfully"));
        }
        return ResponseEntity.notFound().build();
    }

    @PostMapping("/{id}/check-eligibility")
    public ResponseEntity<?> checkEligibility(@PathVariable Long id, @RequestBody Map<String, Object> criteria) {
        Optional<Scholarship> opt = scholarshipRepository.findById(id);
        if (opt.isEmpty()) return ResponseEntity.notFound().build();

        Scholarship s = opt.get();
        List<Map<String, Object>> checks = new ArrayList<>();
        boolean overallEligible = true;

        // Check Deadline
        boolean deadlinePassed = s.getDeadline() != null && s.getDeadline().isBefore(LocalDate.now());
        checks.add(Map.of(
                "rule", "Application Deadline",
                "status", !deadlinePassed,
                "message", deadlinePassed ? "Deadline has passed (" + s.getDeadline() + ")" : "Active application window open"
        ));
        if (deadlinePassed) overallEligible = false;

        // Check CGPA
        Double studentCgpa = criteria.get("cgpa") != null ? Double.valueOf(criteria.get("cgpa").toString()) : null;
        if (s.getMinCgpa() != null) {
            boolean cgpaOk = studentCgpa != null && studentCgpa >= s.getMinCgpa();
            checks.add(Map.of(
                    "rule", "Minimum CGPA Requirement (>= " + s.getMinCgpa() + ")",
                    "status", cgpaOk,
                    "message", cgpaOk ? "Your CGPA (" + studentCgpa + ") qualifies" : "CGPA is below requirement (" + (studentCgpa != null ? studentCgpa : "N/A") + " < " + s.getMinCgpa() + ")"
            ));
            if (!cgpaOk) overallEligible = false;
        }

        // Check Annual Income
        Double studentIncome = criteria.get("annualFamilyIncome") != null ? Double.valueOf(criteria.get("annualFamilyIncome").toString()) : null;
        if (s.getMaxAnnualIncome() != null) {
            boolean incomeOk = studentIncome != null && studentIncome <= s.getMaxAnnualIncome();
            checks.add(Map.of(
                    "rule", "Family Annual Income (<= ₹" + s.getMaxAnnualIncome().longValue() + ")",
                    "status", incomeOk,
                    "message", incomeOk ? "Income qualifies (₹" + studentIncome.longValue() + ")" : "Income exceeds ceiling (₹" + (studentIncome != null ? studentIncome.longValue() : "N/A") + " > ₹" + s.getMaxAnnualIncome().longValue() + ")"
            ));
            if (!incomeOk) overallEligible = false;
        }

        // Check Department
        String studentDept = criteria.get("department") != null ? criteria.get("department").toString() : null;
        if (s.getEligibleDepartment() != null && !s.getEligibleDepartment().equalsIgnoreCase("ALL")) {
            boolean deptOk = studentDept != null && studentDept.equalsIgnoreCase(s.getEligibleDepartment());
            checks.add(Map.of(
                    "rule", "Eligible Department (" + s.getEligibleDepartment() + ")",
                    "status", deptOk,
                    "message", deptOk ? "Department matches" : "Reserved for " + s.getEligibleDepartment()
            ));
            if (!deptOk) overallEligible = false;
        }

        Map<String, Object> result = new HashMap<>();
        result.put("scholarshipId", s.getId());
        result.put("scholarshipTitle", s.getTitle());
        result.put("eligible", overallEligible);
        result.put("checks", checks);
        result.put("requiredDocuments", s.getRequiredDocuments());

        return ResponseEntity.ok(result);
    }
}

