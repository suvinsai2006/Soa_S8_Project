package com.scholar360.notification;

import com.scholar360.notification.entity.Notification;
import com.scholar360.notification.repository.NotificationRepository;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;
import org.springframework.context.annotation.Bean;

@SpringBootApplication
@EnableDiscoveryClient
public class NotificationServiceApplication {

    public static void main(String[] args) {
        SpringApplication.run(NotificationServiceApplication.class, args);
    }

    @Bean
    CommandLineRunner initNotifications(NotificationRepository repo) {
        return args -> {
            if (repo.count() == 0) {
                repo.save(new Notification(
                        1L, "Documents Successfully Verified",
                        "Your documents for 'National Merit Academic Scholarship 2026' have been verified.",
                        "DOCUMENT_VERIFICATION"
                ));
                repo.save(new Notification(
                        2L, "Scholarship Application Approved!",
                        "Congratulations! Your application for 'KL University Chancellor Merit Award' has been APPROVED.",
                        "APPLICATION_STATUS"
                ));
            }
        };
    }
}

