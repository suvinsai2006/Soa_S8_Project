package com.scholar360.document.repository;

import com.scholar360.document.entity.Document;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface DocumentRepository extends JpaRepository<Document, Long> {
    List<Document> findByApplicationId(Long applicationId);
    List<Document> findByStudentId(Long studentId);
    List<Document> findByVerificationStatus(String verificationStatus);
}

