import React, { useState } from 'react';
import { Search, CheckCircle, XCircle, FileText, X, UserPlus, Trash2 } from 'lucide-react';
import { api } from '../api';

export default function StudentPortal({ 
  currentUser, 
  scholarships, 
  applications, 
  students = [],
  onRefresh,
  onOpenAddStudent,
  onDeleteStudent
}) {
  const [tab, setTab] = useState('browse'); // 'browse' or 'applications'
  const [searchTerm, setSearchTerm] = useState('');
  const [applyingScholarship, setApplyingScholarship] = useState(null);
  const [eligibilityResults, setEligibilityResults] = useState({});
  const [docName, setDocName] = useState('Income_Certificate_2026.pdf');
  const [submitting, setSubmitting] = useState(false);

  const userApps = applications.filter(a => a.studentId === currentUser?.id);

  const handleCheckEligibility = async (sch) => {
    const res = await api.checkEligibility(sch.id, currentUser);
    setEligibilityResults(prev => ({
      ...prev,
      [sch.id]: res
    }));
  };

  const handleSubmitApplication = async (e) => {
    e.preventDefault();
    if (!applyingScholarship) return;
    setSubmitting(true);

    const appData = {
      studentId: currentUser.id,
      studentName: currentUser.fullName,
      studentEmail: currentUser.email,
      studentRollNumber: currentUser.rollNumber,
      studentDepartment: currentUser.department,
      studentCgpa: currentUser.cgpa,
      annualFamilyIncome: currentUser.annualFamilyIncome,
      scholarshipId: applyingScholarship.id,
      scholarshipTitle: applyingScholarship.title,
      scholarshipAmount: applyingScholarship.amount,
      status: "SUBMITTED"
    };

    const newApp = await api.apply(appData);
    if (newApp && newApp.id) {
      await api.uploadDocument(newApp.id, currentUser.id, 'INCOME_CERTIFICATE', docName);
    }

    setSubmitting(false);
    setApplyingScholarship(null);
    setTab('applications');
    onRefresh();
  };

  const filtered = scholarships.filter(s =>
    s.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
    s.category.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div>
      {/* Student Profile Strip */}
      <div className="card" style={{
        padding: '16px 20px',
        marginBottom: '20px',
        display: 'flex',
        justifyContent: 'space-between',
        alignItems: 'center',
        flexWrap: 'wrap',
        gap: '12px',
        borderLeft: '4px solid #0d9488'
      }}>
        <div>
          <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
            <h2 style={{ fontSize: '18px', fontWeight: 800, color: '#0f172a' }}>
              {currentUser?.fullName}
            </h2>
            <span className="badge badge-primary">University ID: {currentUser?.rollNumber}</span>
          </div>
          <p style={{ fontSize: '12px', color: '#64748b', marginTop: '2px' }}>
            {currentUser?.department} • Category: <strong>{currentUser?.category}</strong>
          </p>
        </div>

        <div style={{ display: 'flex', gap: '16px', alignItems: 'center', flexWrap: 'wrap' }}>
          <div style={{ display: 'flex', gap: '20px', fontSize: '13px' }}>
            <div>
              <span style={{ color: '#64748b', fontSize: '11px', display: 'block' }}>CGPA</span>
              <strong style={{ color: '#0d9488', fontSize: '16px' }}>{currentUser?.cgpa}</strong>
            </div>
            <div>
              <span style={{ color: '#64748b', fontSize: '11px', display: 'block' }}>Annual Income</span>
              <strong style={{ fontSize: '16px' }}>₹{(currentUser?.annualFamilyIncome / 100000).toFixed(1)}L</strong>
            </div>
            <div>
              <span style={{ color: '#64748b', fontSize: '11px', display: 'block' }}>Applied</span>
              <strong style={{ color: '#16a34a', fontSize: '16px' }}>{userApps.length}</strong>
            </div>
          </div>

          <div style={{ display: 'flex', gap: '8px', alignItems: 'center' }}>
            <button
              onClick={onOpenAddStudent}
              className="btn btn-secondary btn-sm"
              style={{ display: 'flex', alignItems: 'center', gap: '5px', fontSize: '11px' }}
              title="Add a new student profile"
            >
              <UserPlus size={13} color="#0d9488" /> + Add Student
            </button>

            {currentUser?.role === 'STUDENT' && (
              <button
                onClick={() => {
                  if (window.confirm(`Are you sure you want to remove ${currentUser.fullName} (University ID: ${currentUser.rollNumber})?`)) {
                    onDeleteStudent && onDeleteStudent(currentUser.id);
                  }
                }}
                className="btn btn-danger btn-sm"
                style={{ display: 'flex', alignItems: 'center', gap: '5px', fontSize: '11px' }}
                title="Remove this student profile"
              >
                <Trash2 size={13} /> Remove Student
              </button>
            )}
          </div>
        </div>
      </div>

      {/* Clean Navigation Tabs */}
      <div style={{ display: 'flex', gap: '8px', marginBottom: '18px' }}>
        <button
          onClick={() => setTab('browse')}
          style={{
            padding: '7px 16px',
            borderRadius: '6px',
            border: 'none',
            fontWeight: 600,
            fontSize: '13px',
            cursor: 'pointer',
            background: tab === 'browse' ? '#0d9488' : '#e2e8f0',
            color: tab === 'browse' ? '#ffffff' : '#475569',
            transition: 'all 0.15s ease'
          }}
        >
          Explore Scholarships ({scholarships.length})
        </button>

        <button
          onClick={() => setTab('applications')}
          style={{
            padding: '7px 16px',
            borderRadius: '6px',
            border: 'none',
            fontWeight: 600,
            fontSize: '13px',
            cursor: 'pointer',
            background: tab === 'applications' ? '#0d9488' : '#e2e8f0',
            color: tab === 'applications' ? '#ffffff' : '#475569',
            transition: 'all 0.15s ease'
          }}
        >
          My Applications ({userApps.length})
        </button>
      </div>

      {/* TAB 1: BROWSE SCHOLARSHIPS */}
      {tab === 'browse' && (
        <div>
          <div style={{ marginBottom: '16px', position: 'relative' }}>
            <Search size={15} color="#94a3b8" style={{ position: 'absolute', left: '12px', top: '10px' }} />
            <input
              type="text"
              className="input"
              style={{ paddingLeft: '34px' }}
              placeholder="Filter by keyword (e.g. Merit, Need, Tech)..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
          </div>

          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(340px, 1fr))', gap: '14px' }}>
            {filtered.map(s => {
              const elig = eligibilityResults[s.id];
              return (
                <div key={s.id} className="card" style={{ padding: '18px', display: 'flex', flexDirection: 'column' }}>
                  <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: '6px' }}>
                    <span className="badge badge-primary">{s.category}</span>
                    <span style={{ fontSize: '16px', fontWeight: 800, color: '#0d9488' }}>
                      ₹{s.amount?.toLocaleString('en-IN')}
                    </span>
                  </div>

                  <h3 style={{ fontSize: '15px', fontWeight: 700, color: '#0f172a', marginBottom: '4px' }}>
                    {s.title}
                  </h3>
                  <p style={{ fontSize: '12px', color: '#64748b', marginBottom: '12px', flex: 1, lineHeight: 1.4 }}>
                    {s.description}
                  </p>

                  <div style={{
                    background: '#f8fafc',
                    padding: '8px 10px',
                    borderRadius: '6px',
                    fontSize: '11px',
                    marginBottom: '12px',
                    color: '#475569',
                    display: 'flex',
                    flexDirection: 'column',
                    gap: '2px'
                  }}>
                    <div>Required CGPA: <strong>&ge; {s.minCgpa}</strong> (You have: {currentUser?.cgpa})</div>
                    <div>Income Limit: <strong>&le; ₹{s.maxAnnualIncome?.toLocaleString('en-IN')}</strong></div>
                    <div>Provider: <strong>{s.provider}</strong></div>
                  </div>

                  {/* Inline Eligibility Alert */}
                  {elig && (
                    <div style={{
                      padding: '6px 10px',
                      borderRadius: '6px',
                      fontSize: '11px',
                      marginBottom: '10px',
                      background: elig.eligible ? '#f0fdf4' : '#fff1f2',
                      color: elig.eligible ? '#15803d' : '#be123c',
                      border: elig.eligible ? '1px solid #bbf7d0' : '1px solid #fecdd3',
                      display: 'flex',
                      alignItems: 'center',
                      gap: '5px'
                    }}>
                      {elig.eligible ? <CheckCircle size={14} /> : <XCircle size={14} />}
                      <span>{elig.eligible ? 'You meet all eligibility criteria!' : 'Criteria not satisfied.'}</span>
                    </div>
                  )}

                  <div style={{ display: 'flex', gap: '6px', borderTop: '1px solid #f1f5f9', paddingTop: '10px' }}>
                    <button
                      onClick={() => handleCheckEligibility(s)}
                      className="btn btn-secondary btn-sm"
                      style={{ flex: 1 }}
                    >
                      Check Eligibility
                    </button>
                    <button
                      onClick={() => setApplyingScholarship(s)}
                      className="btn btn-primary btn-sm"
                      style={{ flex: 1 }}
                    >
                      Apply Now
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* TAB 2: MY APPLICATIONS */}
      {tab === 'applications' && (
        <div className="card" style={{ padding: '20px' }}>
          <h3 style={{ fontSize: '16px', fontWeight: 800, color: '#0f172a', marginBottom: '14px' }}>
            Submitted Applications &amp; Status
          </h3>

          {userApps.length === 0 ? (
            <div style={{ textAlign: 'center', padding: '32px', color: '#64748b' }}>
              <FileText size={36} color="#cbd5e1" style={{ margin: '0 auto 8px auto' }} />
              <p style={{ fontSize: '13px', fontWeight: 600 }}>No applications submitted yet.</p>
              <button onClick={() => setTab('browse')} className="btn btn-primary btn-sm" style={{ marginTop: '10px' }}>
                Browse Scholarships
              </button>
            </div>
          ) : (
            <div style={{ display: 'flex', flexDirection: 'column', gap: '12px' }}>
              {userApps.map(app => {
                let step = 4;
                if (app.status === 'UNDER_REVIEW') step = 5;
                if (app.status === 'DOCS_VERIFIED') step = 6;
                if (app.status === 'APPROVED') step = 9;

                return (
                  <div key={app.id} style={{ border: '1px solid #e2e8f0', borderRadius: '8px', padding: '16px', background: '#f8fafc' }}>
                    <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: '8px' }}>
                      <div>
                        <h4 style={{ fontSize: '15px', fontWeight: 700, color: '#0f172a' }}>
                          {app.scholarshipTitle}
                        </h4>
                        <p style={{ fontSize: '12px', color: '#64748b' }}>
                          Application Ref: #{app.id} • Concession: ₹{app.scholarshipAmount?.toLocaleString('en-IN')}
                        </p>
                      </div>

                      <span className={`badge ${
                        app.status === 'APPROVED' ? 'badge-success' :
                        app.status === 'DOCS_VERIFIED' ? 'badge-primary' : 'badge-warning'
                      }`}>
                        {app.status.replace('_', ' ')}
                      </span>
                    </div>

                    {/* Progress Bar */}
                    <div style={{ margin: '10px 0' }}>
                      <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '11px', color: '#64748b', marginBottom: '3px' }}>
                        <span>Stage {step} of 9</span>
                        <strong style={{ color: app.status === 'APPROVED' ? '#16a34a' : '#0d9488' }}>
                          {app.status === 'APPROVED' ? 'Grant Approved' : 'In Verification'}
                        </strong>
                      </div>
                      <div style={{ height: '6px', background: '#e2e8f0', borderRadius: '3px', overflow: 'hidden' }}>
                        <div style={{
                          height: '100%',
                          width: `${(step / 9) * 100}%`,
                          background: app.status === 'APPROVED' ? '#16a34a' : '#0d9488',
                          transition: 'width 0.3s ease'
                        }} />
                      </div>
                    </div>

                    {app.remarks && (
                      <div style={{ background: '#ffffff', padding: '8px 10px', borderRadius: '6px', border: '1px solid #e2e8f0', fontSize: '11px', color: '#334155' }}>
                        <strong>Remarks:</strong> {app.remarks}
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          )}
        </div>
      )}

      {/* APPLY MODAL */}
      {applyingScholarship && (
        <div style={{
          position: 'fixed',
          top: 0,
          left: 0,
          right: 0,
          bottom: 0,
          background: 'rgba(0,0,0,0.4)',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          zIndex: 100,
          padding: '20px'
        }}>
          <div className="card" style={{ maxWidth: '440px', width: '100%', padding: '20px', background: '#fff' }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '14px' }}>
              <h3 style={{ fontSize: '16px', fontWeight: 800 }}>Apply for Scholarship</h3>
              <button onClick={() => setApplyingScholarship(null)} style={{ background: 'none', border: 'none', cursor: 'pointer' }}>
                <X size={18} />
              </button>
            </div>

            <form onSubmit={handleSubmitApplication} style={{ display: 'flex', flexDirection: 'column', gap: '12px' }}>
              <div style={{ background: '#f8fafc', padding: '10px', borderRadius: '6px', fontSize: '12px' }}>
                <div><strong>Program:</strong> {applyingScholarship.title}</div>
                <div><strong>Concession Amount:</strong> ₹{applyingScholarship.amount?.toLocaleString('en-IN')}</div>
                <div><strong>Applicant:</strong> {currentUser?.fullName} (University ID: {currentUser?.rollNumber})</div>
                <div><strong>CGPA:</strong> {currentUser?.cgpa}</div>
              </div>

              <div>
                <label style={{ fontSize: '11px', fontWeight: 700, color: '#334155', display: 'block', marginBottom: '3px' }}>
                  Document Name (Income / Grade Sheet)
                </label>
                <input
                  type="text"
                  required
                  className="input"
                  value={docName}
                  onChange={(e) => setDocName(e.target.value)}
                />
              </div>

              <div style={{ display: 'flex', justifyContent: 'flex-end', gap: '8px', marginTop: '6px' }}>
                <button type="button" onClick={() => setApplyingScholarship(null)} className="btn btn-secondary btn-sm">
                  Cancel
                </button>
                <button type="submit" disabled={submitting} className="btn btn-primary btn-sm">
                  {submitting ? 'Submitting...' : 'Submit Application'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
