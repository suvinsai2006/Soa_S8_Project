@echo off
echo ==============================================================================
echo   Scholar360 - Distributed Microservices Cluster
echo   Spring Cloud Eureka + Gateway + 6 Spring Boot Services + React.js
echo ==============================================================================
echo.
echo [1/8] Starting Eureka Discovery Server on :8761 ...
start "Eureka Server :8761" cmd /k "cd backend && mvn spring-boot:run -pl eureka-server"
timeout /t 8 /nobreak >nul

echo [2/8] Starting Spring Cloud API Gateway on :8080 ...
start "API Gateway :8080" cmd /k "cd backend && mvn spring-boot:run -pl api-gateway"
timeout /t 5 /nobreak >nul

echo [3/8] Starting User Service on :8081 ...
start "User Service :8081" cmd /k "cd backend && mvn spring-boot:run -pl user-service"

echo [4/8] Starting Scholarship Service on :8082 ...
start "Scholarship Service :8082" cmd /k "cd backend && mvn spring-boot:run -pl scholarship-service"

echo [5/8] Starting Application Service on :8083 ...
start "Application Service :8083" cmd /k "cd backend && mvn spring-boot:run -pl application-service"

echo [6/8] Starting Document Service on :8084 ...
start "Document Service :8084" cmd /k "cd backend && mvn spring-boot:run -pl document-service"

echo [7/8] Starting Notification Service on :8085 ...
start "Notification Service :8085" cmd /k "cd backend && mvn spring-boot:run -pl notification-service"

echo [8/8] Starting Admin Service on :8086 ...
start "Admin Service :8086" cmd /k "cd backend && mvn spring-boot:run -pl admin-service"

timeout /t 5 /nobreak >nul
echo Starting React.js Frontend on :3000 ...
start "React Frontend :3000" cmd /k "cd frontend && npm run dev"

echo.
echo Microservices cluster online!
echo - Eureka Registry: http://localhost:8761
echo - API Gateway: http://localhost:8080
echo - React UI: http://localhost:3000
pause

