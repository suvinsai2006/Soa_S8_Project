package com.scholar360.application;

import com.scholar360.application.entity.Application;
import com.scholar360.application.repository.ApplicationRepository;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;
import org.springframework.context.annotation.Bean;

@SpringBootApplication
@EnableDiscoveryClient
public class ApplicationServiceApplication {

    public static void main(String[] args) {
        SpringApplication.run(ApplicationServiceApplication.class, args);
    }

    @Bean
    CommandLineRunner initApplications(ApplicationRepository repo) {
        return args -> {
            if (repo.count() == 0) {
                repo.save(new Application(
                        1L, "Student 1", "student1@univ.edu", "2420030115",
                        "Computer Science and Engineering", 8.92, 350000.0,
                        1L, "National Merit Academic Scholarship 2026", 75000.0,
                        "DOCS_VERIFIED", "All documents verified successfully by Faculty Administrator."
                ));

                repo.save(new Application(
                        2L, "Student 2", "student2@univ.edu", "2420030128",
                        "Computer Science and Engineering", 9.15, 420000.0,
                        4L, "KL University Chancellor's Merit Award", 40000.0,
                        "APPROVED", "Exemplary CGPA 9.15. Direct award granted."
                ));

                repo.save(new Application(
                        3L, "Student 3", "student3@univ.edu", "2420030124",
                        "Computer Science and Engineering", 8.45, 280000.0,
                        2L, "Dr. APJ Abdul Kalam Need-cum-Merit Grant", 50000.0,
                        "UNDER_REVIEW", "Income certificate under verification with revenue portal."
                ));
            }
        };
    }
}
