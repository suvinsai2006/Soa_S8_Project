package com.scholar360.application.repository;

import com.scholar360.application.entity.Application;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface ApplicationRepository extends JpaRepository<Application, Long> {
    List<Application> findByStudentId(Long studentId);
    List<Application> findByScholarshipId(Long scholarshipId);
    List<Application> findByStatus(String status);
}

