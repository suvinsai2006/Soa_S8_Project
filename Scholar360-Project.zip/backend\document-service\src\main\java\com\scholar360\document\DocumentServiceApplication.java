package com.scholar360.document;

import com.scholar360.document.entity.Document;
import com.scholar360.document.repository.DocumentRepository;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;
import org.springframework.context.annotation.Bean;

@SpringBootApplication
@EnableDiscoveryClient
public class DocumentServiceApplication {

    public static void main(String[] args) {
        SpringApplication.run(DocumentServiceApplication.class, args);
    }

    @Bean
    CommandLineRunner initDocuments(DocumentRepository repo) {
        return args -> {
            if (repo.count() == 0) {
                repo.save(new Document(1L, 1L, "INCOME_CERTIFICATE", "MeeSeva_Income_Certificate_2026.pdf", "application/pdf", 312000L, "VERIFIED", "Verified from government revenue database."));
                repo.save(new Document(1L, 1L, "ACADEMIC_TRANSCRIPT", "KL_University_Official_Transcript.pdf", "application/pdf", 524000L, "VERIFIED", "CGPA 8.92 confirmed."));
                repo.save(new Document(3L, 3L, "INCOME_CERTIFICATE", "EWS_Income_Proof_Tehsildar.pdf", "application/pdf", 298000L, "PENDING", "Pending revenue officer counter-signature verification."));
            }
        };
    }
}

