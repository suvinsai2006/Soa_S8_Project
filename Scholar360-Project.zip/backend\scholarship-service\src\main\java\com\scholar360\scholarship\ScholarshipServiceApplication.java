package com.scholar360.scholarship;

import com.scholar360.scholarship.entity.Scholarship;
import com.scholar360.scholarship.repository.ScholarshipRepository;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;
import org.springframework.context.annotation.Bean;

import java.time.LocalDate;

@SpringBootApplication
@EnableDiscoveryClient
public class ScholarshipServiceApplication {

    public static void main(String[] args) {
        SpringApplication.run(ScholarshipServiceApplication.class, args);
    }

    @Bean
    CommandLineRunner initScholarships(ScholarshipRepository repo) {
        return args -> {
            if (repo.count() == 0) {
                repo.save(new Scholarship(
                        "National Merit Academic Scholarship 2026",
                        "Recognizing exceptional academic brilliance among undergraduate engineering students.",
                        "Merit-Based", "Ministry of Education", 75000.0,
                        LocalDate.now().plusMonths(3), 8.5, 800000.0,
                        "ALL", 100, 45, "ACTIVE",
                        "College ID, Grade Sheet, Income Certificate"
                ));

                repo.save(new Scholarship(
                        "Dr. APJ Abdul Kalam Need-cum-Merit Grant",
                        "Financial assistance aimed at supporting economically weaker students.",
                        "Need-Based", "AICTE", 50000.0,
                        LocalDate.now().plusMonths(2), 7.5, 400000.0,
                        "ALL", 150, 82, "ACTIVE",
                        "Income Certificate, Academic Marksheet, ID Proof"
                ));

                repo.save(new Scholarship(
                        "Women in Tech & Computing Excellence Fellowship",
                        "Empowering women engineers in computer science and AI disciplines.",
                        "Women in STEM", "Tech Innovation Foundation", 90000.0,
                        LocalDate.now().plusMonths(4), 8.0, 600000.0,
                        "Computer Science and Engineering", 50, 28, "ACTIVE",
                        "Resume, Academic Transcript, College ID"
                ));

                repo.save(new Scholarship(
                        "KL University Chancellor's Merit Award",
                        "Institutional honors grant awarded to top-ranking students across disciplines.",
                        "Merit-Based", "KL University", 40000.0,
                        LocalDate.now().plusMonths(1), 9.0, 1000000.0,
                        "Computer Science and Engineering", 30, 12, "ACTIVE",
                        "Official Transcript, Student ID"
                ));
            }
        };
    }
}

