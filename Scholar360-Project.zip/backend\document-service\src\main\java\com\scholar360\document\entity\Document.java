package com.scholar360.document.entity;

import jakarta.persistence.*;
import java.time.LocalDateTime;

@Entity
@Table(name = "documents")
public class Document {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false)
    private Long applicationId;

    @Column(nullable = false)
    private Long studentId;

    @Column(nullable = false)
    private String documentType; // INCOME_CERTIFICATE, ACADEMIC_TRANSCRIPT, ID_PROOF, CASTE_CERTIFICATE

    @Column(nullable = false)
    private String fileName;

    private String fileType;
    private Long fileSize;

    @Lob
    @Column(columnDefinition = "CLOB")
    private String fileContentBase64; // Can hold simulated base64 or upload data

    private LocalDateTime uploadDate = LocalDateTime.now();

    @Column(nullable = false)
    private String verificationStatus = "PENDING"; // PENDING, VERIFIED, REJECTED

    private String verificationNotes;
    private String verifiedBy;
    private LocalDateTime verifiedAt;

    public Document() {}

    public Document(Long applicationId, Long studentId, String documentType, String fileName,
                    String fileType, Long fileSize, String verificationStatus, String verificationNotes) {
        this.applicationId = applicationId;
        this.studentId = studentId;
        this.documentType = documentType;
        this.fileName = fileName;
        this.fileType = fileType;
        this.fileSize = fileSize;
        this.verificationStatus = verificationStatus;
        this.verificationNotes = verificationNotes;
        this.uploadDate = LocalDateTime.now();
    }

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }
    public Long getApplicationId() { return applicationId; }
    public void setApplicationId(Long applicationId) { this.applicationId = applicationId; }
    public Long getStudentId() { return studentId; }
    public void setStudentId(Long studentId) { this.studentId = studentId; }
    public String getDocumentType() { return documentType; }
    public void setDocumentType(String documentType) { this.documentType = documentType; }
    public String getFileName() { return fileName; }
    public void setFileName(String fileName) { this.fileName = fileName; }
    public String getFileType() { return fileType; }
    public void setFileType(String fileType) { this.fileType = fileType; }
    public Long getFileSize() { return fileSize; }
    public void setFileSize(Long fileSize) { this.fileSize = fileSize; }
    public String getFileContentBase64() { return fileContentBase64; }
    public void setFileContentBase64(String fileContentBase64) { this.fileContentBase64 = fileContentBase64; }
    public LocalDateTime getUploadDate() { return uploadDate; }
    public void setUploadDate(LocalDateTime uploadDate) { this.uploadDate = uploadDate; }
    public String getVerificationStatus() { return verificationStatus; }
    public void setVerificationStatus(String verificationStatus) { this.verificationStatus = verificationStatus; }
    public String getVerificationNotes() { return verificationNotes; }
    public void setVerificationNotes(String verificationNotes) { this.verificationNotes = verificationNotes; }
    public String getVerifiedBy() { return verifiedBy; }
    public void setVerifiedBy(String verifiedBy) { this.verifiedBy = verifiedBy; }
    public LocalDateTime getVerifiedAt() { return verifiedAt; }
    public void setVerifiedAt(LocalDateTime verifiedAt) { this.verifiedAt = verifiedAt; }
}

