package com.scholar360.user.controller;

import com.scholar360.user.entity.User;
import com.scholar360.user.repository.UserRepository;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.*;

@RestController
@RequestMapping("/api/users")
@CrossOrigin(origins = "*")
public class UserController {

    private final UserRepository userRepository;

    public UserController(UserRepository userRepository) {
        this.userRepository = userRepository;
    }

    @PostMapping("/register")
    public ResponseEntity<?> register(@RequestBody User user) {
        if (userRepository.findByEmail(user.getEmail()).isPresent()) {
            return ResponseEntity.badRequest().body(Map.of("error", "Email is already registered"));
        }
        if (user.getRole() == null || user.getRole().isBlank()) {
            user.setRole("STUDENT");
        }
        User saved = userRepository.save(user);
        return ResponseEntity.ok(saved);
    }

    @PostMapping("/login")
    public ResponseEntity<?> login(@RequestBody Map<String, String> credentials) {
        String email = credentials.get("email");
        String password = credentials.get("password");

        Optional<User> userOpt = userRepository.findByEmail(email);
        if (userOpt.isPresent() && userOpt.get().getPassword().equals(password)) {
            User user = userOpt.get();
            Map<String, Object> resp = new HashMap<>();
            resp.put("id", user.getId());
            resp.put("fullName", user.getFullName());
            resp.put("email", user.getEmail());
            resp.put("role", user.getRole());
            resp.put("rollNumber", user.getRollNumber());
            resp.put("department", user.getDepartment());
            resp.put("cgpa", user.getCgpa());
            resp.put("annualFamilyIncome", user.getAnnualFamilyIncome());
            resp.put("category", user.getCategory());
            resp.put("token", "dummy-jwt-token-scholar360-" + user.getId());
            return ResponseEntity.ok(resp);
        }
        return ResponseEntity.status(401).body(Map.of("error", "Invalid email or password"));
    }

    @GetMapping("/profile/{id}")
    public ResponseEntity<?> getProfile(@PathVariable Long id) {
        return userRepository.findById(id)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    @PutMapping("/profile/{id}")
    public ResponseEntity<?> updateProfile(@PathVariable Long id, @RequestBody User updated) {
        return userRepository.findById(id).map(user -> {
            if (updated.getFullName() != null) user.setFullName(updated.getFullName());
            if (updated.getPhone() != null) user.setPhone(updated.getPhone());
            if (updated.getCgpa() != null) user.setCgpa(updated.getCgpa());
            if (updated.getAnnualFamilyIncome() != null) user.setAnnualFamilyIncome(updated.getAnnualFamilyIncome());
            if (updated.getDepartment() != null) user.setDepartment(updated.getDepartment());
            if (updated.getCategory() != null) user.setCategory(updated.getCategory());
            User saved = userRepository.save(user);
            return ResponseEntity.ok(saved);
        }).orElse(ResponseEntity.notFound().build());
    }

    @GetMapping
    public List<User> getAllUsers() {
        return userRepository.findAll();
    }

    @GetMapping("/students")
    public List<User> getStudents() {
        return userRepository.findByRole("STUDENT");
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<?> deleteUser(@PathVariable Long id) {
        if (userRepository.existsById(id)) {
            userRepository.deleteById(id);
            return ResponseEntity.ok(Map.of("message", "User deleted successfully"));
        }
        return ResponseEntity.notFound().build();
    }
}

