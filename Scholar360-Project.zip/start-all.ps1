# Scholar360 One-Click Startup Script (PowerShell)
Write-Host "==============================================================================" -ForegroundColor Cyan
Write-Host "       Scholar360 - Digital Scholarship Management Platform" -ForegroundColor Yellow
Write-Host "       Java Spring Boot + Spring Cloud + Microservices + React.js" -ForegroundColor White
Write-Host "       Course: SOA Programming and Microservices (24SDCS03)" -ForegroundColor Gray
Write-Host "==============================================================================" -ForegroundColor Cyan

$backendPath = Join-Path $PSScriptRoot "backend"
$frontendPath = Join-Path $PSScriptRoot "frontend"

Write-Host "`n[1/2] Starting Spring Boot Microservices Backend on http://localhost:8080 ..." -ForegroundColor Green
Start-Process powershell -ArgumentList "-NoExit", "-Command", "cd '$backendPath'; mvn.cmd spring-boot:run -pl scholar360-all-in-one"

Start-Sleep -Seconds 5

Write-Host "[2/2] Starting React.js Frontend on http://localhost:3000 ..." -ForegroundColor Green
Start-Process powershell -ArgumentList "-NoExit", "-Command", "cd '$frontendPath'; npm.cmd run dev"

Write-Host "`nPlatform running! Open http://localhost:3000 in your browser." -ForegroundColor Yellow
