@echo off
echo ==============================================================================
echo        Scholar360 - Digital Scholarship Management Platform
echo        Course: SOA Programming and Microservices (24SDCS03)
echo        Java Spring Boot + Spring Cloud + Microservices + React.js
echo ==============================================================================
echo.
echo [1/2] Starting Spring Boot Microservices Backend on http://localhost:8080 ...
start "Scholar360 Backend :8080" cmd /k "cd backend && mvn spring-boot:run -pl scholar360-all-in-one"

timeout /t 5 /nobreak >nul

echo [2/2] Starting React.js Frontend on http://localhost:3000 ...
start "Scholar360 React Frontend :3000" cmd /k "cd frontend && npm run dev"

echo.
echo ==============================================================================
echo Platform started successfully!
echo - React.js Web UI: http://localhost:3000
echo - Spring Boot Microservices API: http://localhost:8080/api/scholarships
echo - H2 Database Console: http://localhost:8080/h2-console
echo ==============================================================================
pause
