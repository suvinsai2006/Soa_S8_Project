# Scholar360 - Distributed Microservices Startup Script (PowerShell)
Write-Host "==============================================================================" -ForegroundColor Cyan
Write-Host "  Scholar360 - Distributed Spring Cloud Microservices Cluster" -ForegroundColor Yellow
Write-Host "  Course: SOA Programming and Microservices (24SDCS03)" -ForegroundColor White
Write-Host "==============================================================================" -ForegroundColor Cyan

$backendPath = Join-Path $PSScriptRoot "backend"
$frontendPath = Join-Path $PSScriptRoot "frontend"

Write-Host "`n[1/8] Starting Eureka Discovery Server on :8761 ..." -ForegroundColor Green
Start-Process powershell -ArgumentList "-NoExit", "-Command", "cd '$backendPath'; mvn.cmd spring-boot:run -pl eureka-server"
Start-Sleep -Seconds 8

Write-Host "[2/8] Starting Spring Cloud Gateway on :8080 ..." -ForegroundColor Green
Start-Process powershell -ArgumentList "-NoExit", "-Command", "cd '$backendPath'; mvn.cmd spring-boot:run -pl api-gateway"
Start-Sleep -Seconds 5

Write-Host "[3/8] Starting User Service on :8081 ..." -ForegroundColor Green
Start-Process powershell -ArgumentList "-NoExit", "-Command", "cd '$backendPath'; mvn.cmd spring-boot:run -pl user-service"

Write-Host "[4/8] Starting Scholarship Service on :8082 ..." -ForegroundColor Green
Start-Process powershell -ArgumentList "-NoExit", "-Command", "cd '$backendPath'; mvn.cmd spring-boot:run -pl scholarship-service"

Write-Host "[5/8] Starting Application Service on :8083 ..." -ForegroundColor Green
Start-Process powershell -ArgumentList "-NoExit", "-Command", "cd '$backendPath'; mvn.cmd spring-boot:run -pl application-service"

Write-Host "[6/8] Starting Document Service on :8084 ..." -ForegroundColor Green
Start-Process powershell -ArgumentList "-NoExit", "-Command", "cd '$backendPath'; mvn.cmd spring-boot:run -pl document-service"

Write-Host "[7/8] Starting Notification Service on :8085 ..." -ForegroundColor Green
Start-Process powershell -ArgumentList "-NoExit", "-Command", "cd '$backendPath'; mvn.cmd spring-boot:run -pl notification-service"

Write-Host "[8/8] Starting Admin Service on :8086 ..." -ForegroundColor Green
Start-Process powershell -ArgumentList "-NoExit", "-Command", "cd '$backendPath'; mvn.cmd spring-boot:run -pl admin-service"

Start-Sleep -Seconds 4
Write-Host "`nStarting React.js Frontend on :3000 ..." -ForegroundColor Green
Start-Process powershell -ArgumentList "-NoExit", "-Command", "cd '$frontendPath'; npm.cmd run dev"

Write-Host "`nAll Spring Cloud Microservices started!" -ForegroundColor Yellow
Write-Host "- Eureka Dashboard: http://localhost:8761" -ForegroundColor Cyan
Write-Host "- Spring Cloud Gateway: http://localhost:8080" -ForegroundColor Cyan
Write-Host "- React.js Web Application: http://localhost:3000" -ForegroundColor Cyan

